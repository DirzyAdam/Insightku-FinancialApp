package com.dicoding.myinsight.ui.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class PageViewModel : ViewModel() {

    // _sectionIndex adalah MutableLiveData yang hanya bisa diubah dalam ViewModel
    private val _sectionIndex = MutableLiveData<Int>()

    // Fungsi untuk memperbarui nilai _sectionIndex
    fun setSectionIndex(index: Int) {
        _sectionIndex.value = index
    }
}