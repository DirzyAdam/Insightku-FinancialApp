package com.dicoding.myinsight.ui.main

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.myinsight.adapters.TransactionsAdapter
import com.dicoding.myinsight.data.DBOpenHelper
import com.dicoding.myinsight.databinding.FragmentListBinding
import com.dicoding.myinsight.interfaces.PageFragment

class ListFragment : PageFragment() {

    private var _binding: FragmentListBinding? = null
    private val binding get() = _binding!!
    private var transactionsAdapter: TransactionsAdapter? = null
    private lateinit var db: DBOpenHelper

    override fun onAttach(context: Context) {
        super.onAttach(context)
        // Initialize DBOpenHelper
        db = DBOpenHelper(context)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment using ViewBinding
        _binding = FragmentListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Set up RecyclerView with TransactionsAdapter
        setupRecyclerView()
    }

    private fun setupRecyclerView() {
        // Fetch all transactions (income and expense)
        val cursor = db.getAllTransactions() // No filtering by isExpense

        if (cursor != null) {
            transactionsAdapter = TransactionsAdapter(cursor, activity as TransactionsAdapter.OnItemClickListener)
            binding.transactionList.apply {
                layoutManager = LinearLayoutManager(context)
                adapter = transactionsAdapter
            }
        } else {
            // Handle the case where the cursor is null
            binding.transactionList.visibility = View.GONE // Hide RecyclerView if no data available
        }
    }

    override fun notifyDataUpdate() {
        if (!isAdded) return // Ensure fragment is attached to the activity
        val cursor = db.getAllTransactions() // Fetch all transactions again
        cursor?.let {
            // Update the adapter with the new cursor
            transactionsAdapter?.swapCursor(it)
            transactionsAdapter?.notifyDataSetChanged()
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh the data when the fragment resumes
        notifyDataUpdate()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // Clean up the binding reference and adapter to avoid memory leaks
        _binding = null
        transactionsAdapter = null
    }
}