package com.dicoding.myinsight.model

data class Prediction(
    val date: String,
    val predictedAmount: Int
)

fun getDummyPredictions(): List<Prediction> {
    return listOf(
        Prediction("Mon, 16 Dec 2024 00:00:00 GMT", 101000),
        Prediction("Tue, 17 Dec 2024 00:00:00 GMT", 111000),
        Prediction("Wed, 18 Dec 2024 00:00:00 GMT", 151000),
        Prediction("Thu, 19 Dec 2024 00:00:00 GMT", 108000),
        Prediction("Fri, 20 Dec 2024 00:00:00 GMT", 112000),
        Prediction("Sat, 21 Dec 2024 00:00:00 GMT", 106000),
        Prediction("Sun, 22 Dec 2024 00:00:00 GMT", 68000),
        Prediction("Mon, 23 Dec 2024 00:00:00 GMT", 99000),
        Prediction("Tue, 24 Dec 2024 00:00:00 GMT", 84000),
        Prediction("Wed, 25 Dec 2024 00:00:00 GMT", 109000),
        Prediction("Thu, 26 Dec 2024 00:00:00 GMT", 58000),
        Prediction("Fri, 27 Dec 2024 00:00:00 GMT", 46000),
        Prediction("Sat, 28 Dec 2024 00:00:00 GMT", 109000),
        Prediction("Sun, 29 Dec 2024 00:00:00 GMT", 73000),
        Prediction("Mon, 30 Dec 2024 00:00:00 GMT", 97000)
    )
}

fun main() {
    val predictions = getDummyPredictions()
    predictions.forEach {
        println("Date: ${it.date}, Predicted Amount: ${it.predictedAmount}")
    }
}