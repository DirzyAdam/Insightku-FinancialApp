package com.dicoding.myinsight.ui.main

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.myinsight.data.DBOpenHelper

class StatisticsViewModel : ViewModel() {

    private val _balance = MutableLiveData<Float>()
    val balance: LiveData<Float> get() = _balance

    private val _allIncomes = MutableLiveData<Float>()
    val allIncomes: LiveData<Float> get() = _allIncomes

    private val _allExpenses = MutableLiveData<Float>()
    val allExpenses: LiveData<Float> get() = _allExpenses

    private val _expenseMap = MutableLiveData<HashMap<String, Float>>()
    val expenseMap: LiveData<HashMap<String, Float>> get() = _expenseMap

    private val _incomeMap = MutableLiveData<HashMap<String, Float>>()
    val incomeMap: LiveData<HashMap<String, Float>> get() = _incomeMap

    fun fetchData(context: Context) {
        val db = DBOpenHelper(context)

        _balance.value = db.getBalance()
        _expenseMap.value = db.getValueByCategory(true)
        _incomeMap.value = db.getValueByCategory(false)
        _allIncomes.value = db.getOperations(false)
        _allExpenses.value = kotlin.math.abs(db.getOperations(true))
    }
}
