package com.dicoding.myinsight.ui.main

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class PredictionViewModel : ViewModel() {
    val selectedTransaction = MutableLiveData<Pair<String, String>>() // Menyimpan dua input yang dipilih (misal, input1 dan input2)
}
