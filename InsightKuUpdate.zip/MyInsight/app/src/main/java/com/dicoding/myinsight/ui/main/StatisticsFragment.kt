package com.dicoding.myinsight.ui.main

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.dicoding.myinsight.R
import com.dicoding.myinsight.data.DBOpenHelper
import com.dicoding.myinsight.databinding.FragmentStatisticsBinding
import com.dicoding.myinsight.interfaces.PageFragment
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.components.Description
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.utils.ColorTemplate

class StatisticsFragment : PageFragment() {

    private var _binding: FragmentStatisticsBinding? = null
    private val binding get() = _binding!!

    private var balance: Float = 0f
    private var allIncomes: Float = 0f
    private var allExpenses: Float = 0f
    private var expenseMap = HashMap<String, Float>()
    private var incomeMap = HashMap<String, Float>()

    // Handler and Runnable for auto-refresh
    private val handler = Handler(Looper.getMainLooper())
    private val refreshRunnable = object : Runnable {
        override fun run() {
            // Refresh data and update the UI
            fetchData()
            updateUI()
            // Schedule the next refresh (e.g., every 10 seconds)
            handler.postDelayed(this, 10000) // 10000 milliseconds = 10 seconds
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment using ViewBinding
        _binding = FragmentStatisticsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // Ensure fragment is attached before interacting with the activity
        if (isAdded) {
            // Initialize fields with data from the db
            fetchData()
            // Update the UI with the new data
            updateUI()
            // Start auto-refreshing
            handler.postDelayed(refreshRunnable, 3000) // Start immediately with 10 seconds delay
        }
    }

    fun fetchData() {
        if (isAdded) {  // Ensure fragment is attached before accessing activity
            val db = DBOpenHelper(requireActivity().applicationContext)

            // Fetch balance, category values, and operations
            balance = db.getBalance()
            expenseMap = db.getValueByCategory(true)
            incomeMap = db.getValueByCategory(false)
            allIncomes = db.getOperations(false)
            allExpenses = kotlin.math.abs(db.getOperations(true))
        }
    }

    fun updateUI() {
        if (isAdded) {  // Ensure fragment is attached before updating the UI
            // Update UI elements with the fetched data
            binding.tvBalance.text = balance.toString()
            binding.tvExpenses.text = allExpenses.toString()
            binding.tvIncomes.text = allIncomes.toString()

            // Setup PieCharts for expenses and incomes
            setupChart(expenseMap, binding.expensesPiechart, getString(R.string.expenses_text))
            setupChart(incomeMap, binding.incomesPiechart, getString(R.string.incomes_text))
        }
    }

    override fun notifyDataUpdate() {
        if (isAdded) {  // Ensure fragment is attached before performing data update
            fetchData()
            updateUI()
        }
    }

    private fun setupChart(map: HashMap<String, Float>, chart: PieChart, description: String) {
        if (isAdded) {  // Ensure fragment is attached before interacting with chart
            val pieEntries = ArrayList<PieEntry>()

            if (map.isNotEmpty()) {
                // Populate PieEntries from the map data
                for ((key, value) in map) {
                    pieEntries.add(PieEntry(value, key))
                }

                // Set chart description
                val desc = Description().apply {
                    text = description
                    textSize = 20f
                }
                chart.description = desc

                // Create PieDataSet and set data
                val dataSet = PieDataSet(pieEntries, "")
                val data = PieData(dataSet)
                chart.data = data

                // Set chart colors and animate
                dataSet.setColors(ColorTemplate.JOYFUL_COLORS.toList())
                chart.animateY(1000)  // Optional: Add animation for the chart

                chart.notifyDataSetChanged()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // Clean up the binding reference and remove auto-refresh handler to prevent memory leaks
        _binding = null
        handler.removeCallbacks(refreshRunnable) // Stop the periodic refresh
    }
}

