package com.dicoding.myinsight.adapters

import android.database.Cursor
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.myinsight.R
import com.dicoding.myinsight.databinding.TransactionListItemBinding

class TransactionsAdapter(
    private var data: Cursor,
    private val itemClickListener: OnItemClickListener
) : RecyclerView.Adapter<TransactionsAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = TransactionListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return data.count
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        if (data.moveToPosition(position)) {
            // Ambil data dari Cursor
            val titleIndex = data.getColumnIndexOrThrow("title")
            val valueIndex = data.getColumnIndexOrThrow("value")
            val categoryIndex = data.getColumnIndexOrThrow("category_name")
            val isExpenseIndex = data.getColumnIndexOrThrow("is_expense") // Ambil kolom is_expense

            val title = data.getString(titleIndex) ?: "Untitled"
            val value = data.getFloat(valueIndex)
            val category = data.getString(categoryIndex) ?: "Unknown"
            val isExpense = data.getInt(isExpenseIndex)

            // Tentukan warna indikator berdasarkan is_expense
            val indicatorColor = if (isExpense == 0) R.color.colorIncome else R.color.colorExpense

            holder.bind(title, category, value, indicatorColor)
        } else {
            Log.e(this.javaClass.name, "Failed to move Cursor to position $position in onBindViewHolder")
        }
    }

    // Fungsi untuk mengganti Cursor jika data diperbarui
    fun swapCursor(cursor: Cursor) {
        if (data != cursor) {
            data = cursor
            notifyDataSetChanged()
        }
    }

    inner class ViewHolder(private val binding: TransactionListItemBinding) :
        RecyclerView.ViewHolder(binding.root), View.OnClickListener {

        private val mTitle = binding.tvTransactionTitle
        private val mGroup = binding.tvGroup
        private val mValue = binding.value
        private val mIndicator = binding.indicatorView

        // Fungsi bind untuk mengatur tampilan
        fun bind(title: String, category: String, value: Float, indicatorRes: Int) {
            mTitle.text = title
            mGroup.text = category
            mValue.text = value.toString()
            mIndicator.setBackgroundResource(indicatorRes)
            itemView.setOnClickListener(this)
        }

        override fun onClick(v: View?) {
            val adapterPosition = adapterPosition
            if (adapterPosition != RecyclerView.NO_POSITION) {
                if (data.moveToPosition(adapterPosition)) {
                    val selectedId = data.getInt(data.getColumnIndexOrThrow("_id"))
                    itemClickListener.onClick(selectedId)
                }
            }
        }
    }

    interface OnItemClickListener {
        fun onClick(id: Int)
    }
}