package com.dicoding.myinsight.interfaces

import androidx.fragment.app.Fragment

open class PageFragment: Fragment() {
    open fun notifyDataUpdate() = Unit
}