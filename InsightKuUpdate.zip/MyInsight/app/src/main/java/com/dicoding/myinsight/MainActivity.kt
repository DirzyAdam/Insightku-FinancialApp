package com.dicoding.myinsight

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.dicoding.myinsight.adapters.SectionsPagerAdapter
import com.dicoding.myinsight.adapters.TransactionsAdapter
import com.dicoding.myinsight.databinding.ActivityMainBinding
import com.dicoding.myinsight.interfaces.PageFragment
import com.dicoding.myinsight.ui.main.TransactionActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.tabs.TabLayoutMediator

// Default list of categories for transactions
val DEFAULT_CAT_LIST = listOf(
    "General", "Food", "Entertainment", "Sports", "Public Transport",
    "Home", "Work", "Health", "Electronics", "Clothing", "Family", "Services", "Holidays"
)

class MainActivity : AppCompatActivity(), TransactionsAdapter.OnItemClickListener {

    companion object {
        const val REQUEST_ADD = 20
        const val REQUEST_EDIT = 21
        const val REQ_ADD_OK = 21
        const val REQ_EDIT_OK = 22
        const val EXTRA_TRANSACTION = "extra_id"
        const val EXTRA_CODE = "request_code"
        const val EXTRA_TARGET_TAB = "target_tab" // Tambahkan ini untuk target tab
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var sectionsPagerAdapter: SectionsPagerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // **Langsung tampilkan ListFragment**
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize the SectionsPagerAdapter for ViewPager2
        sectionsPagerAdapter = SectionsPagerAdapter(this)
        binding.viewPager.adapter = sectionsPagerAdapter

        // Set up TabLayout with ViewPager2
        TabLayoutMediator(binding.tabs, binding.viewPager) { tab, position ->
            tab.text = sectionsPagerAdapter.getTabTitle(position)
        }.attach()

        // Set tab ke ListFragment (tab pertama) secara default
        binding.viewPager.currentItem = 0

        // FloatingActionButton setup
        val fab: FloatingActionButton = binding.fab
        fab.setOnClickListener {
            startAddActivity() // Start the activity for adding a new transaction
        }
    }

    // Tidak perlu lagi cek login
    override fun onClick(id: Int) {
        val intent = Intent(this, TransactionActivity::class.java).apply {
            putExtra(EXTRA_CODE, REQUEST_EDIT)
            putExtra(EXTRA_TRANSACTION, id)
        }
        startActivity(intent)
    }

    private fun startAddActivity() {
        val intent = Intent(this, TransactionActivity::class.java).apply {
            putExtra(EXTRA_CODE, REQUEST_ADD)
        }
        startActivity(intent)
    }
}
