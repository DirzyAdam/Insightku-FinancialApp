package com.dicoding.myinsight.adapters

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.dicoding.myinsight.ui.main.PredictFragment
import com.dicoding.myinsight.ui.main.ListFragment
import com.dicoding.myinsight.ui.main.StatisticsFragment


class SectionsPagerAdapter(
    fragmentActivity: AppCompatActivity
) : FragmentStateAdapter(fragmentActivity) {

    // Menentukan jumlah tab
    override fun getItemCount(): Int {
        return 3 // Ubah jumlah tab menjadi 3
    }

    // Menentukan fragmen yang akan digunakan untuk setiap halaman
    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> ListFragment() // Tab pertama
            1 -> StatisticsFragment() // Tab kedua
            2 -> PredictFragment() // Tab ketiga, fragment Predict
            else -> ListFragment() // Default tab jika ada kesalahan
        }
    }

    // Menyediakan judul tab
    fun getTabTitle(position: Int): CharSequence? {
        return when (position) {
            0 -> "List"
            1 -> "Statistics"
            2 -> "Predict" // Judul untuk tab Predict
            else -> "Unknown"
        }
    }
}
