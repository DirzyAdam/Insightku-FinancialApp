package com.dicoding.myinsight.ui.main

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ScrollView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.myinsight.data.DBContract
import com.dicoding.myinsight.data.DBOpenHelper
import com.dicoding.myinsight.databinding.FragmentPredictBinding
import com.dicoding.myinsight.model.Prediction
import com.dicoding.myinsight.model.getDummyPredictions
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.utils.ColorTemplate
import kotlinx.coroutines.launch

class PredictFragment : Fragment() {

    private var _binding: FragmentPredictBinding? = null
    private val binding get() = _binding!!

    private val predictionViewModel: PredictionViewModel by activityViewModels()

    private lateinit var expenseAdapter: ExpenseAdapter
    private lateinit var dbHelper: DBOpenHelper
    private lateinit var autoRefreshHandler: Handler
    private lateinit var autoRefreshRunnable: Runnable

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate layout asli
        _binding = FragmentPredictBinding.inflate(inflater, container, false)

        // Bungkus dengan ScrollView secara programatis
        val scrollView = ScrollView(requireContext()).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            addView(_binding?.root) // Tambahkan layout asli ke dalam ScrollView
        }

        return scrollView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Inisialisasi DBHelper
        dbHelper = DBOpenHelper(requireContext())

        // Setup RecyclerView untuk menampilkan data expense
        setupRecyclerView()

        // Ambil data expense pertama kali
        loadLatestExpenses()

        // Setup Auto-Refresh
        setupAutoRefresh()

        binding.btnPredict.setOnClickListener {
            // Ganti ini dengan data dummy
            showDummyPredictions()
        }
    }

    private fun setupRecyclerView() {
        binding?.let { safeBinding ->
            expenseAdapter = ExpenseAdapter { expense ->
                // Menggunakan expense yang dipilih sebagai input
                safeBinding.tvPrediction.text = expense // Update untuk menunjukkan expense yang dipilih
            }

            safeBinding.transactionList.layoutManager = LinearLayoutManager(requireContext())
            safeBinding.transactionList.adapter = expenseAdapter
        }
    }

    private fun loadLatestExpenses() {
        lifecycleScope.launch {
            val cursor = dbHelper.getLatestExpenses() // Fetch latest expenses from DB
            val expenses = mutableListOf<Triple<String, String, String>>() // List berisi Triple (title, value, category)

            cursor?.use {
                val titleIndex = cursor.getColumnIndex(DBContract.TransactionEntry.COLUMN_TITLE)
                val valueIndex = cursor.getColumnIndex(DBContract.TransactionEntry.COLUMN_VALUE)
                val categoryIndex = cursor.getColumnIndex(DBContract.TransactionEntry.COLUMN_CATEGORY)

                if (titleIndex >= 0 && valueIndex >= 0 && categoryIndex >= 0) {
                    while (cursor.moveToNext()) {
                        val title = cursor.getString(titleIndex) ?: "Unknown"
                        val value = cursor.getFloat(valueIndex).toString() // Nominal
                        val category = cursor.getInt(categoryIndex).toString() // Mengambil kategori
                        expenses.add(Triple(title, value, category))
                    }
                }
            }

            if (expenses.isNotEmpty()) {
                expenseAdapter.updateData(expenses)
            } else {
                Toast.makeText(requireContext(), "No expenses to display.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupAutoRefresh() {
        autoRefreshHandler = Handler(Looper.getMainLooper())
        autoRefreshRunnable = Runnable {
            loadLatestExpenses()
            autoRefreshHandler.postDelayed(autoRefreshRunnable, 10000) // Refresh setiap 10 detik
        }
        autoRefreshHandler.postDelayed(autoRefreshRunnable, 10000) // Mulai refresh setelah 10 detik
    }

    private fun showDummyPredictions() {
        // Mengambil data dummy dan menampilkannya
        val predictions = getDummyPredictions()

        binding?.let { safeBinding ->
            safeBinding.tvPrediction.text = "Predictions: ${predictions.size} predictions"
            displayPieChart(predictions)
        }
    }

    private fun displayPieChart(predictions: List<Prediction>) {
        val pieEntries = ArrayList<PieEntry>()

        // Mengisi data untuk Pie Chart
        predictions.forEachIndexed { index, prediction ->
            pieEntries.add(PieEntry(prediction.predictedAmount.toFloat(), "Prediction ${index + 1}"))
        }

        val pieDataSet = PieDataSet(pieEntries, "Prediction Breakdown")
        pieDataSet.setColors(*ColorTemplate.COLORFUL_COLORS)  // Set warna yang berbeda
        pieDataSet.valueTextSize = 12f
        pieDataSet.valueTextColor = Color.BLACK

        val pieData = PieData(pieDataSet)

        binding?.let { safeBinding ->
            safeBinding.predictionLineChart.data = pieData
            safeBinding.predictionLineChart.invalidate() // Refresh chart
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // Pastikan auto-refresh dihentikan saat fragment dihancurkan
        autoRefreshHandler.removeCallbacks(autoRefreshRunnable)
        _binding = null
    }
}
