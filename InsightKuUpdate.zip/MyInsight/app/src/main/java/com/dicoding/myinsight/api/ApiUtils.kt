package com.dicoding.myinsight.api

import retrofit2.Response

// Fungsi utilitas untuk mengonversi respons Retrofit menjadi ApiResponse
suspend fun <T> handleApiResponse(call: suspend () -> Response<T>): ApiResponse<T> {
    return try {
        val response = call()
        if (response.isSuccessful) {
            response.body()?.let {
                ApiResponse.Success(it)
            } ?: ApiResponse.Error("Response body is null", response.code())
        } else {
            ApiResponse.Error("Error: ${response.message()}", response.code())
        }
    } catch (e: Exception) {
        ApiResponse.Error("Exception: ${e.message}")
    }
}
