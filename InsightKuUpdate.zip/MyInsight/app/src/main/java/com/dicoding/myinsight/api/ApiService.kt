    package com.dicoding.myinsight.api

    import retrofit2.Response
    import retrofit2.http.GET
    import retrofit2.http.Query

    interface ApiService{
        @GET("predict")
        suspend fun predict(@Query("input1") input1: String, @Query("input2") input2: String): Response<PredictionResponse>
    }

    data class PredictionResponse(
        val predictions: List<Prediction>
    )

    data class Prediction(
        val Date: String,
        val Predicted_Amount: Int
    )
