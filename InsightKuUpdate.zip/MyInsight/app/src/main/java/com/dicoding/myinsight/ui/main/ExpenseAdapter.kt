package com.dicoding.myinsight.ui.main

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.myinsight.databinding.TransactionListItemBinding

class ExpenseAdapter(private val onItemClick: (String) -> Unit) :
    RecyclerView.Adapter<ExpenseAdapter.ExpenseViewHolder>() {

    private var expenses: List<Triple<String, String, String>> = listOf()

    fun updateData(newExpenses: List<Triple<String, String, String>>) {
        expenses = newExpenses
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExpenseViewHolder {
        val binding = TransactionListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ExpenseViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ExpenseViewHolder, position: Int) {
        val expense = expenses[position]
        holder.bind(expense.first, expense.second, expense.third) // title, value, category
    }

    override fun getItemCount(): Int = expenses.size

    inner class ExpenseViewHolder(private val binding: TransactionListItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(title: String, value: String, category: String) {
            binding.tvTransactionTitle.text = title
            binding.tvGroup.text = category // Tampilkan kategori
            binding.value.text = value // Tampilkan nominal
            binding.root.setOnClickListener {
                onItemClick(title)
            }
        }
    }
}