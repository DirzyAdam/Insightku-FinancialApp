package com.dicoding.myinsight.ui.main

import android.Manifest
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.dicoding.myinsight.DEFAULT_CAT_LIST
import com.dicoding.myinsight.MainActivity
import com.dicoding.myinsight.R
import com.dicoding.myinsight.api.Prediction
import com.dicoding.myinsight.api.RetrofitClientFlask
import com.dicoding.myinsight.data.DBOpenHelper
import com.dicoding.myinsight.data.Transaction
import com.dicoding.myinsight.databinding.ActivityTransactionBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class TransactionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTransactionBinding
    private lateinit var selectedDate: Date
    private var requestCode = 0
    private var calendar = Calendar.getInstance()
    private var selectedCategoryId = 0
    private var transactionId = 0

    companion object {
        private const val REQUEST_CAMERA_PERMISSION = 101
        private const val REQUEST_GALLERY_PERMISSION = 102
        private const val REQUEST_IMAGE_CAPTURE = 1
        private const val REQUEST_PICK_IMAGE = 2
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTransactionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        selectedDate = calendar.time

        // Retrieve request code from intent
        val requestIntent = intent
        requestCode = requestIntent.getIntExtra(MainActivity.EXTRA_CODE, MainActivity.REQUEST_ADD)
        binding.dateSpinner.text = convertDate(selectedDate)

        // Initialize DatePicker
        val dateListener = DatePickerDialog.OnDateSetListener { _, year, month, day ->
            calendar.set(Calendar.YEAR, year)
            calendar.set(Calendar.MONTH, month)
            calendar.set(Calendar.DAY_OF_MONTH, day)
            updateDate()
        }

        binding.dateSpinner.setOnClickListener {
            DatePickerDialog(this, dateListener, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
        }

        val catSpinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, DEFAULT_CAT_LIST)
        catSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.groupSpinner.adapter = catSpinnerAdapter

        if (requestCode == MainActivity.REQUEST_EDIT) {
            transactionId = intent.getIntExtra(MainActivity.EXTRA_TRANSACTION, MainActivity.REQUEST_EDIT)
            val db = DBOpenHelper(this)
            val transaction = db.getTransaction(transactionId)
            transaction?.let { extractData(it) } ?: finish()
        }

        binding.groupSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
                selectedCategoryId = 0
            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedCategoryId = position
            }
        }

        // Handle button save
        binding.buttonOk.setOnClickListener {
            saveAndFinish()
        }

        // Handle button scan for Camera and Gallery
        binding.buttonScan.setOnClickListener {
            showImagePickerOptions()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        super.onCreateOptionsMenu(menu)
        if (requestCode == MainActivity.REQUEST_EDIT) {
            menuInflater.inflate(R.menu.item_menu, menu)
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_delete_item -> {
                deleteAndFinish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    private fun extractData(data: Transaction) {
        binding.valueInput.setText(data.value.toString())
        binding.etTitle.setText(data.title)
        selectedCategoryId = data.category
        binding.groupSpinner.setSelection(data.category, false)
        binding.expenseSwitch.isChecked = data.isExpense
        calendar.time = data.date
        updateDate()
        binding.description.setText(data.desc)
    }

    private fun convertDate(date: Date): String {
        val format = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
        return format.format(date)
    }

    private fun updateDate() {
        val date = convertDate(calendar.time)
        binding.dateSpinner.text = date
        selectedDate = calendar.time
    }

    private fun saveAndFinish() {
        val value = binding.valueInput.text.toString().toFloat()
        val title = binding.etTitle.text.toString()
        val description = binding.description.text.toString()
        val db = DBOpenHelper(this)
        var resultCode = -1

        lifecycleScope.launch {
            try {
                val response = RetrofitClientFlask.service.predict(value.toString(), selectedCategoryId.toString())
                if (response.isSuccessful) {
                    val predictionResponse = response.body()
                    predictionResponse?.let {
                        displayPredictionToast(it.predictions)
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(this@TransactionActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        if (requestCode == MainActivity.REQUEST_ADD) {
            db.insertTransaction(value, binding.expenseSwitch.isChecked, selectedDate, title, selectedCategoryId, description)
            resultCode = MainActivity.REQ_ADD_OK
        } else if (requestCode == MainActivity.REQUEST_EDIT) {
            db.updateTransaction(Transaction(transactionId, value, title, binding.expenseSwitch.isChecked, selectedDate, description, selectedCategoryId))
            resultCode = MainActivity.REQ_EDIT_OK
        }

        setResult(resultCode, Intent())
        finish()
    }

    private fun deleteAndFinish() {
        if (requestCode == MainActivity.REQUEST_EDIT) {
            val db = DBOpenHelper(this)
            db.deleteTransaction(transactionId)
        }
        setResult(MainActivity.REQ_EDIT_OK, Intent())
        finish()
    }

    private fun showImagePickerOptions() {
        val options = arrayOf("Kamera", "Galeri")
        android.app.AlertDialog.Builder(this)
            .setTitle("Pilih Sumber Gambar")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> openCamera()
                    1 -> openGallery()
                }
            }.show()
    }

    private fun openCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivityForResult(intent, REQUEST_IMAGE_CAPTURE)
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA_PERMISSION)
        }
    }

    private fun openGallery() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent, REQUEST_PICK_IMAGE)
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), REQUEST_GALLERY_PERMISSION)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_CAMERA_PERMISSION -> if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) openCamera()
            REQUEST_GALLERY_PERMISSION -> if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) openGallery()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            when (requestCode) {
                REQUEST_IMAGE_CAPTURE -> {
                    Toast.makeText(this, "Gambar berhasil diambil dari Kamera", Toast.LENGTH_SHORT).show()
                }
                REQUEST_PICK_IMAGE -> {
                    val selectedImage: Uri? = data?.data
                    Toast.makeText(this, "Gambar berhasil dipilih dari Galeri", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun displayPredictionToast(predictions: List<Prediction>) {
        predictions.forEach {
            Toast.makeText(this, "Date: ${it.Date}, Amount: ${it.Predicted_Amount}", Toast.LENGTH_SHORT).show()
        }
    }
}
