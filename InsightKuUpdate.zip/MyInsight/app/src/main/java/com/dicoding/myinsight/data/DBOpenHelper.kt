package com.dicoding.myinsight.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.provider.BaseColumns
import android.util.Log
import com.dicoding.myinsight.DEFAULT_CAT_LIST
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date

private const val SQL_CREATE_GROUP_ENTRIES =
    "CREATE TABLE ${DBContract.CategoryEntry.TABLE_NAME} (" +
            "${BaseColumns._ID} INTEGER PRIMARY KEY," +
            "${DBContract.CategoryEntry.COLUMN_NAME} TEXT NOT NULL," +
            "${DBContract.CategoryEntry.COLUMN_PARENT_GROUP_ID} INTEGER);"

private const val SQL_CREATE_TRANSACTION_ENTRIES =
    "CREATE TABLE ${DBContract.TransactionEntry.TABLE_NAME} (" +
            "${BaseColumns._ID} INTEGER PRIMARY KEY, " +
            "${DBContract.TransactionEntry.COLUMN_VALUE} REAL DEFAULT 0, " +
            "${DBContract.TransactionEntry.COLUMN_TITLE} TEXT, " +
            "${DBContract.TransactionEntry.COLUMN_IS_EXPENSE} INTEGER DEFAULT 1, " +
            "${DBContract.TransactionEntry.COLUMN_DATE} TEXT, " +
            "${DBContract.TransactionEntry.COLUMN_DESCRIPTION} TEXT, " +
            "${DBContract.TransactionEntry.COLUMN_CATEGORY} INTEGER NOT NULL, " +
            "FOREIGN KEY (${DBContract.TransactionEntry.COLUMN_CATEGORY}) REFERENCES " +
            "${DBContract.CategoryEntry.TABLE_NAME} (${BaseColumns._ID}) " +
            ");"

private const val SQL_DROP_GROUPS = "DROP TABLE IF EXISTS ${DBContract.CategoryEntry.TABLE_NAME}"
private const val SQL_DROP_TRANSACTIONS = "DROP TABLE IF EXISTS ${DBContract.TransactionEntry.TABLE_NAME}"

private const val ORDER_BY_DATE = " ORDER BY datetime(${DBContract.TransactionEntry.COLUMN_DATE}) DESC"

class DBOpenHelper(context: Context):
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        const val DATABASE_NAME = "finances.db"
        const val DATABASE_VERSION = 1
    }

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL("PRAGMA foreign_keys=ON")
        db?.execSQL(SQL_CREATE_GROUP_ENTRIES)
        db?.execSQL(SQL_CREATE_TRANSACTION_ENTRIES)
        createDefaultGroups(db)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL(SQL_DROP_TRANSACTIONS)
        db?.execSQL(SQL_DROP_GROUPS)
        onCreate(db)
    }

    /**
     * Is used to initialize categories table. Inserts basic categories.
     *
     * @param db The database
     * */
    private fun createDefaultGroups(db: SQLiteDatabase?) {
        for (cat in DEFAULT_CAT_LIST) {
            val group = ContentValues().apply {
                put(DBContract.CategoryEntry.COLUMN_NAME, cat) }
            db?.insert(DBContract.CategoryEntry.TABLE_NAME, null, group)
        }
    }

    fun getGroups(): Cursor? {
        val db = this.readableDatabase
        return db?.rawQuery("SELECT ${DBContract.CategoryEntry.COLUMN_NAME} from " +
                "${DBContract.CategoryEntry.TABLE_NAME}", null)
    }

    // Menambahkan metode untuk mengambil transaksi expense terbaru
    fun getLatestExpenses(limit: Int = 15): Cursor? {
        val query = "SELECT * FROM ${DBContract.TransactionEntry.TABLE_NAME} " +
                "WHERE ${DBContract.TransactionEntry.COLUMN_IS_EXPENSE} = 1 " +
                "ORDER BY datetime(${DBContract.TransactionEntry.COLUMN_DATE}) DESC " +
                "LIMIT ?"

        val db = this.readableDatabase
        return db.rawQuery(query, arrayOf(limit.toString()))
    }

    fun insertTransaction(value: Float, isExpense: Boolean, date: Date, title: String, category: Int,
                          desc: String): Long? {
        val expenseFlag = if(isExpense) 1 else 0
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

        val newTransaction = ContentValues().apply {
            put(DBContract.TransactionEntry.COLUMN_VALUE, value)
            put(DBContract.TransactionEntry.COLUMN_IS_EXPENSE, expenseFlag)
            put(DBContract.TransactionEntry.COLUMN_DATE, dateFormat.format(date))
            put(DBContract.TransactionEntry.COLUMN_TITLE, title)
            put(DBContract.TransactionEntry.COLUMN_CATEGORY, category)
            put(DBContract.TransactionEntry.COLUMN_DESCRIPTION, desc)
        }

        val db = this.writableDatabase
        return db?.insert(DBContract.TransactionEntry.TABLE_NAME, null, newTransaction)
    }

    fun getBalance(): Float {
        val expenses = getOperations(true)
        val incomes = getOperations(false)
        return incomes - expenses
    }

    fun getOperations(expense: Boolean): Float {
        val selection = " WHERE ${DBContract.TransactionEntry.COLUMN_IS_EXPENSE} = ?"
        val selectionArg = if(expense) "1" else "0"
        return getSum(selection, arrayOf(selectionArg))
    }

    private fun getSum(selection: String, selectionArgs: Array<String>): Float {
        var query = "SELECT sum(${DBContract.TransactionEntry.COLUMN_VALUE}) FROM " +
                "${DBContract.TransactionEntry.TABLE_NAME}"
        val db = this.readableDatabase
        val cursor = db.rawQuery(query + selection, selectionArgs)
        return if(cursor.moveToFirst()) {
            cursor.getFloat(0)
        } else 0 as Float
    }

    // Menambahkan metode untuk mengambil semua transaksi
    fun getAllTransactions(): Cursor? {
        val query = """
        SELECT 
            t.${BaseColumns._ID},
            t.${DBContract.TransactionEntry.COLUMN_TITLE} AS title,
            t.${DBContract.TransactionEntry.COLUMN_VALUE} AS value,
            t.${DBContract.TransactionEntry.COLUMN_IS_EXPENSE} AS is_expense,
            c.${DBContract.CategoryEntry.COLUMN_NAME} AS category_name
        FROM ${DBContract.TransactionEntry.TABLE_NAME} t
        LEFT JOIN ${DBContract.CategoryEntry.TABLE_NAME} c
        ON t.${DBContract.TransactionEntry.COLUMN_CATEGORY} = c.${BaseColumns._ID}
        ORDER BY datetime(t.${DBContract.TransactionEntry.COLUMN_DATE}) DESC
    """
        return readableDatabase.rawQuery(query, null)
    }

    fun getTransaction(id: Int): Transaction? {
        val query = "SELECT * FROM ${DBContract.TransactionEntry.TABLE_NAME} WHERE ${BaseColumns._ID} = ?"
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())

        val db = this.readableDatabase
        val cursor = db?.rawQuery(query, arrayOf(id.toString()))

        return cursor?.use {
            if (it.moveToFirst()) {
                val transactionId = it.getInt(0)
                val value = it.getFloat(1)
                val title = it.getString(2)
                val isExpense = it.getInt(3) == 1
                val date = dateFormat.parse(it.getString(4))
                val desc = it.getString(5)
                val category = it.getInt(6)
                Transaction(transactionId, value, title, isExpense, date, desc, category)
            } else {
                null // Kembalikan null jika tidak ada data
            }
        }
    }

    fun updateTransaction(transaction: Transaction) {

        val whereClause = "${BaseColumns._ID} = ?"
        val expenseFlag = if(transaction.isExpense) 1 else 0
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

        val newTransaction = ContentValues().apply {
            put(DBContract.TransactionEntry.COLUMN_VALUE, transaction.value)
            put(DBContract.TransactionEntry.COLUMN_IS_EXPENSE, expenseFlag)
            put(DBContract.TransactionEntry.COLUMN_DATE, dateFormat.format(transaction.date))
            put(DBContract.TransactionEntry.COLUMN_TITLE, transaction.title)
            put(DBContract.TransactionEntry.COLUMN_CATEGORY, transaction.category)
            put(DBContract.TransactionEntry.COLUMN_DESCRIPTION, transaction.desc)
        }

        val db = this.writableDatabase
        val rowsUpdated = db.update("${DBContract.TransactionEntry.TABLE_NAME}", newTransaction, whereClause, arrayOf(transaction.id.toString()))
        Log.d(this.javaClass.name, "Updated $rowsUpdated row")
    }

    fun deleteTransaction(id: Int) {
        val whereClause = "${BaseColumns._ID} = ?"
        val db = this.writableDatabase
        val rowsUpdated = db.delete("${DBContract.TransactionEntry.TABLE_NAME}", whereClause, arrayOf(id.toString()))
        Log.d(this.javaClass.name, "Updated $rowsUpdated rows")
    }

    fun getLatestExpenses(): Cursor? {
        val db = this.readableDatabase
        return db.rawQuery(
            "SELECT * FROM ${DBContract.TransactionEntry.TABLE_NAME} WHERE ${DBContract.TransactionEntry.COLUMN_IS_EXPENSE} = 1 ORDER BY ${DBContract.TransactionEntry.COLUMN_DATE} DESC LIMIT 15",
            null
        )
    }

    // Menambahkan metode untuk mendapatkan nilai berdasarkan kategori (expense atau income)
    fun getValueByCategory(isExpense: Boolean): HashMap<String, Float> {
        val map = HashMap<String, Float>()
        val expenseFlag = if (isExpense) 1 else 0

        val query = "SELECT c.${DBContract.CategoryEntry.COLUMN_NAME}, " +
                "SUM(t.${DBContract.TransactionEntry.COLUMN_VALUE}) " +
                "FROM ${DBContract.TransactionEntry.TABLE_NAME} t " +
                "JOIN ${DBContract.CategoryEntry.TABLE_NAME} c " +
                "ON t.${DBContract.TransactionEntry.COLUMN_CATEGORY} = c.${BaseColumns._ID} " +
                "WHERE t.${DBContract.TransactionEntry.COLUMN_IS_EXPENSE} = ? " +
                "GROUP BY c.${DBContract.CategoryEntry.COLUMN_NAME}"

        val db = this.readableDatabase
        val cursor = db.rawQuery(query, arrayOf(expenseFlag.toString()))

        if (cursor != null) {
            while (cursor.moveToNext()) {
                val categoryName = cursor.getString(0) // Nama kategori
                val value = cursor.getFloat(1) // Total nilai
                map[categoryName] = value
            }
            cursor.close()
        }

        return map
    }
}
