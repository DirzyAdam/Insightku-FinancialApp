package com.dicoding.myinsight.login

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.dicoding.myinsight.MainActivity
import com.dicoding.myinsight.R
import com.dicoding.myinsight.pref.UserModel
import com.dicoding.myinsight.pref.UserPreference
import com.dicoding.myinsight.pref.UserRepository
import com.dicoding.myinsight.pref.dataStore

import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var userRepository: UserRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val userPreference = UserPreference.getInstance(dataStore)
        userRepository = UserRepository.getInstance(userPreference)

        setupAction()
    }

    private fun setupAction() {
        findViewById<Button>(R.id.loginButton).setOnClickListener {
            val email = "example@mail.com"
            val token = "dummy_token"

            lifecycleScope.launch {
                userRepository.saveSession(UserModel(email, token, true))
                startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                finish()
            }
        }
    }
}
