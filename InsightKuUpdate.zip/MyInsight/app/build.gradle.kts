plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.dicoding.myinsight"
    compileSdk = 35  // Updated to 35

    defaultConfig {
        applicationId = "com.dicoding.myinsight"
        minSdk = 24
        targetSdk = 35 // Set targetSdk to 35 for better compatibility
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    // Core and AppCompat Libraries
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.constraintlayout)

    // Lifecycle Libraries
    implementation(libs.androidx.lifecycle.livedata.ktx.v260)
    implementation(libs.androidx.lifecycle.viewmodel.ktx.v260)

    // Navigation Libraries
    implementation(libs.androidx.navigation.fragment.ktx)
    implementation(libs.androidx.navigation.ui.ktx)

    // Testing Libraries
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)

    // Legacy support and lifecycle extensions
    implementation(libs.androidx.legacy.support.v4) // Legacy support for older APIs
    implementation(libs.androidx.lifecycle.runtime.ktx) // For LiveData and ViewModel lifecycle extensions

    // Kotlin standard library
    implementation(libs.kotlin.stdlib) // Kotlin standard library

    // MPAndroidChart for charting
    implementation(libs.mpandroidchart) // For MPAndroidChart (charting library)

    // Retrofit and networking
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    implementation("com.squareup.retrofit2:converter-gson:2.9.0") // For Gson converter with Retrofit

    // OkHttp and logging for network request logging (important for Retrofit)
    implementation("com.squareup.okhttp3:okhttp:4.10.0") // OkHttp dependency
    implementation("com.squareup.okhttp3:logging-interceptor:4.10.0") // Logging interceptor for OkHttp

    // Room for local database (if needed)
    implementation("androidx.room:room-runtime:2.5.1")
    annotationProcessor("androidx.room:room-compiler:2.5.1") // Room database annotation processor

    // Glide for image loading (optional, if needed)
    implementation("com.github.bumptech.glide:glide:4.15.1")
    annotationProcessor("com.github.bumptech.glide:compiler:4.15.1") // Glide compiler for annotations

    // Activity KTX for better activity handling
    implementation("androidx.activity:activity-ktx:1.6.0")
    //datastore
    implementation("androidx.datastore:datastore-preferences:1.0.0")

    //grafik
    implementation ("com.github.PhilJay:MPAndroidChart:v3.1.0")
    //sada
}
