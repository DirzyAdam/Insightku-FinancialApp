package com.example.insight.ui.page

import Transaction
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material.icons.filled.Payment
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.sp
import getTransactions

@Composable
fun CardItem(transaction: Transaction) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),  // Padding di dalam card
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.Payment,  // Ikon pembayaran
                contentDescription = "Transaction Icon",
                modifier = Modifier.size(40.dp),
                tint = Color(0xFF35D486)  // Warna ikon
            )
            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = transaction.amount,
                    fontSize = 14.sp,
                    color = Color(0xFF35D486)
                )
            }
            Text(
                text = transaction.date,
                fontSize = 12.sp,
                color = Color.Gray
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewCardItem() {
    // Menggunakan data transaksi yang dibuat
    val transactions = getTransactions()
    Column(modifier = Modifier.fillMaxWidth()) {
        transactions.forEach { transaction ->
            CardItem(transaction)
        }
    }
}
