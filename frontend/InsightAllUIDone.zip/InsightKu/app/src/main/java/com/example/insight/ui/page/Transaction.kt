import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.insight.R


data class Transaction(
    val title: String,  // Nama transaksi (misalnya: belanja, transportasi)
    val amount: String, // Jumlah uang yang terlibat dalam transaksi
    val date: String    // Tanggal transaksi
)

// Simulasi fungsi untuk mendapatkan daftar transaksi
fun getTransactions(): List<Transaction> {
    return listOf(
        Transaction("Groceries", "Rp 100,000", "2024-11-20"),
        Transaction("Transport", "Rp 50,000", "2024-11-21"),
        Transaction("Entertainment", "Rp 200,000", "2024-11-22"),
        Transaction("Salary", "Rp 5,000,000", "2024-11-23")
    )
}
@Composable
fun AddTransactionScreen(navController: NavController) {
    // State untuk kategori yang dipilih
    var selectedCategory by remember { mutableStateOf("Select Category") }
    var expanded by remember { mutableStateOf(false) } // Untuk mengontrol dropdown

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFEFF5F5))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF24285B))
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Add Transaction",
                color = Color.White,
                style = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Bold)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 100.dp, start = 16.dp, end = 16.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                DateSelector(label = "Day")
                DateSelector(label = "Month")
                DateSelector(label = "Year")
            }

            Spacer(modifier = Modifier.height(20.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Enter Amount",
                    style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium),
                    color = Color(0xFF24285B)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF343B94)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "300.000",
                        color = Color.White,
                        style = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Dropdown untuk kategori
            // Dropdown untuk kategori
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp) // Menambahkan jarak dengan elemen lain
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Category",
                        style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium),
                        color = Color(0xFF24285B)
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF24285B))
                            .clickable { expanded = !expanded }
                            .padding(horizontal = 16.dp, vertical = 8.dp) // Padding di dalam kotak dropdown
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = selectedCategory,
                                color = Color.White,
                                style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Dropdown Icon",
                                tint = Color.White
                            )
                        }
                    }
                }

                // Menu dropdown
                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false },
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White)
                ) {
                    val categories = listOf(
                        "Healthcare", "Food", "Shopping",
                        "Entertainment", "Living", "Transport",
                        "Utilities", "HouseHold", "Education", "Investment"
                    )
                    categories.forEach { category ->
                        DropdownMenuItem(
                            text = { Text(category, color = Color.Black) },
                            onClick = {
                                selectedCategory = category
                                expanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            Button(
                onClick = { /* Add Expense */ },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF437DFB)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .clip(RoundedCornerShape(30.dp))
            ) {
                Text(
                    text = "Add Expense",
                    color = Color.White,
                    style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Bold)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { navController.popBackStack() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDFF7E2)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .clip(RoundedCornerShape(30.dp))
            ) {
                Text(
                    text = "Cancel",
                    color = Color(0xFF24285B),
                    style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Bold)
                )
            }
        }
    }
}

@Composable
fun DateSelector(label: String) {
    Box(
        modifier = Modifier
            .width(100.dp)
            .height(50.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF343B94)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = Color.White,
            style = TextStyle(fontSize = 16.sp)
        )
    }
}

@Preview
@Composable
fun PreviewAddTransactionScreen() {
    val navController = rememberNavController()  // Membuat instance sementara dari NavController
    AddTransactionScreen(navController = navController)
}
