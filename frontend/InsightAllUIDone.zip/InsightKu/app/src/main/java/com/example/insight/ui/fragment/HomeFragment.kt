package com.example.insight.ui.fragment

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.insight.R
import com.example.insight.ui.page.CardItem
import getTransactions
import java.text.NumberFormat
import java.util.*

@Composable
fun HomeFragment(modifier: Modifier = Modifier, onAddMoney: () -> Unit, navController: NavController) {
    val balance = remember { mutableStateOf(5_000_000) }
    val context = LocalContext.current

    val formattedBalance = NumberFormat.getCurrencyInstance(Locale("id", "ID")).format(balance.value)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(color = Color(0xFF24285B))
            .padding(16.dp)
    ) {
        // Profile Section
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 16.dp, top = 30.dp)
                .clickable {
                    navController.navigate("profile") // Pindah ke fragment profile
                }
        ) {
            Image(
                painter = painterResource(id = R.drawable.profile),
                contentDescription = "Profile Picture",
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .border(2.dp, Color.White, CircleShape)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "Welcome! John",
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
            }
        }

        // Top Card (Your Balance)
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 100.dp)
                .fillMaxWidth(0.85f)
                .requiredHeight(201.dp)
                .clip(RoundedCornerShape(13.5.dp))
                .background(Color(0xff343b94))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(30.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = "Total Balances",
                    color = Color.White,
                    fontSize = 16.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = formattedBalance,
                    color = Color(0xff35d486),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Add Money button
        TextButton(
            onClick = { onAddMoney() },
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 220.dp)
                .fillMaxWidth(0.78f)
                .requiredHeight(43.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(30.dp))
                    .background(Color(0xff437dfb))
            ) {
                Text(
                    text = "+ Add Money",
                    color = Color(0xffdff7e2),
                    textAlign = TextAlign.Center,
                    style = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold),
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }

        // Saving Progress
        SavingProgress(current = 1_500_000, target = 5_000_000, modifier = Modifier.padding(top = 300.dp))

        // Recent Transactions
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 450.dp)
                .fillMaxWidth()
        ) {
            Text(
                text = "Recent Transaction",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 16.dp, bottom = 8.dp)
            )

            val transactions = getTransactions()
            Column(modifier = Modifier.fillMaxWidth()) {
                transactions.forEach { transaction ->
                    CardItem(transaction)
                }
            }
        }

        // Bottom Navigation
        BottomNavigationBar(navController = navController, modifier = Modifier.align(Alignment.BottomCenter))
    }
}

@Composable
fun SavingProgress(current: Int, target: Int, modifier: Modifier = Modifier) {
    val progress = current.toFloat() / target.toFloat()
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 70.dp)
    ) {
        Text(
            text = "Saving Progress",
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xff343b94))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(progress)
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xff35d486))
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Rp $current / Rp $target",
            color = Color.White,
            fontSize = 14.sp
        )
    }
}

@Composable
fun BottomNavigationBar(navController: NavController, modifier: Modifier = Modifier) {
    val icons = listOf(
        Pair(R.drawable.home, "home"),
        Pair(R.drawable.expense, "expense"),
        Pair(R.drawable.analisis, "analysis"),
        Pair(R.drawable.goals, "goals")
    )

    val currentRoute = remember { mutableStateOf("home") } // Simpan route saat ini

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(70.dp)
            .clip(RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp))
            .background(color = Color(0xffdff7e2))
            .padding(horizontal = 40.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxSize()
        ) {
            icons.forEach { icon ->
                val isSelected = currentRoute.value == icon.second
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            currentRoute.value = icon.second
                            navController.navigate(icon.second)
                        }
                ) {
                    Image(
                        painter = painterResource(id = icon.first),
                        contentDescription = icon.second,
                        modifier = Modifier.size(25.dp),
                        colorFilter = if (isSelected) {
                            androidx.compose.ui.graphics.ColorFilter.tint(Color(0xff437dfb)) // Warna biru jika dipilih
                        } else {
                            androidx.compose.ui.graphics.ColorFilter.tint(Color.Black) // Warna hitam jika tidak dipilih
                        }
                    )
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewHomeFragment() {
    val navController = rememberNavController()
    HomeFragment(onAddMoney = {}, navController = navController)
}