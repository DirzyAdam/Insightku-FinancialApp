import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.Image
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.insight.R
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign

class SignUp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_sign_up)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}

@Composable
fun CreateAccount(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(color = Color(0xFFFFFFFF)) // Background color as per reference
    ) {
        // Header Background
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp) // Height similar to the reference provided
                .background(color = Color(0xFF24285B)), // Blue background color for header
            contentAlignment = Alignment.Center
        ) {
            // Create Account Text inside the header
            Text(
                text = "Create Account",
                color = Color(0xFFDFF7E2),
                textAlign = TextAlign.Center,
                style = TextStyle(fontSize = 30.sp)
            )
        }

        // Time Display (e.g. 16:04) in the top-left corner
        Text(
            text = "16:04",
            color = Color.White,
            style = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Medium),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 37.dp, top = 9.dp)
        )

        // Sign Up Form Fields

        // Full Name Field
        BasicTextField(
            value = "full name",
            onValueChange = {},
            textStyle = TextStyle(
                color = Color(0xFF0E3E3E).copy(alpha = 0.45f),
                fontSize = 14.sp
            ),
            decorationBox = { innerTextField ->
                Box(
                    modifier = Modifier
                        .border(1.dp, Color(0xFFDFF7E2), RoundedCornerShape(10.dp))
                        .background(Color(0xFFDFF7E2), RoundedCornerShape(10.dp))
                        .padding(start = 12.dp, top = 10.dp, bottom = 10.dp)
                ) {
                    if ("" == "Full name") {
                        Text("Full name", color = Color(0xFF0E3E3E).copy(alpha = 0.45f))
                    }
                    innerTextField()
                }
            },
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 37.dp, top = 240.dp)
                .fillMaxWidth(0.85f)
                .height(41.dp)
        )


        // Email Field
        BasicTextField(
            value = "",
            onValueChange = {},
            textStyle = TextStyle(
                color = Color(0xFF0E3E3E).copy(alpha = 0.45f),
                fontSize = 14.sp
            ),
            decorationBox = { innerTextField ->
                Box(
                    modifier = Modifier
                        .border(1.dp, Color(0xFFDFF7E2), RoundedCornerShape(10.dp))
                        .background(Color(0xFFDFF7E2), RoundedCornerShape(10.dp))
                        .padding(start = 12.dp, top = 10.dp, bottom = 10.dp)
                ) {
                    if ("" == "") {
                        Text("example@example.com", color = Color(0xFF0E3E3E).copy(alpha = 0.45f))
                    }
                    innerTextField()
                }
            },
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 37.dp, top = 323.dp)
                .fillMaxWidth(0.85f)
                .height(41.dp)
        )

        // Date of Birth Field
        BasicTextField(
            value = "",
            onValueChange = {},
            textStyle = TextStyle(
                color = Color(0xFF0E3E3E).copy(alpha = 0.45f),
                fontSize = 14.sp
            ),
            decorationBox = { innerTextField ->
                Box(
                    modifier = Modifier
                        .border(1.dp, Color(0xFFDFF7E2), RoundedCornerShape(10.dp))
                        .background(Color(0xFFDFF7E2), RoundedCornerShape(10.dp))
                        .padding(start = 12.dp, top = 10.dp, bottom = 10.dp)
                ) {
                    if ("" == "") {
                        Text("DD/MM/YYYY", color = Color(0xFF0E3E3E).copy(alpha = 0.45f))
                    }
                    innerTextField()
                }
            },
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 37.dp, top = 406.dp)
                .fillMaxWidth(0.85f)
                .height(41.dp)
        )

        // Password Field
        BasicTextField(
            value = "",
            onValueChange = {},
            textStyle = TextStyle(
                color = Color(0xFF0E3E3E).copy(alpha = 0.45f),
                fontSize = 14.sp
            ),
            decorationBox = { innerTextField ->
                Box(
                    modifier = Modifier
                        .border(1.dp, Color(0xFFDFF7E2), RoundedCornerShape(10.dp))
                        .background(Color(0xFFDFF7E2), RoundedCornerShape(10.dp))
                        .padding(start = 12.dp, top = 10.dp, bottom = 10.dp)
                ) {
                    if ("" == "") {
                        Text("password", color = Color(0xFF0E3E3E).copy(alpha = 0.45f))
                    }
                    innerTextField()
                }
            },
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 37.dp, top = 489.dp)
                .fillMaxWidth(0.85f)
                .height(41.dp)
        )

        // Confirm Password Field
        BasicTextField(
            value = "",
            onValueChange = {},
            textStyle = TextStyle(
                color = Color(0xFF0E3E3E).copy(alpha = 0.45f),
                fontSize = 14.sp
            ),
            decorationBox = { innerTextField ->
                Box(
                    modifier = Modifier
                        .border(1.dp, Color(0xFFDFF7E2), RoundedCornerShape(10.dp))
                        .background(Color(0xFFDFF7E2), RoundedCornerShape(10.dp))
                        .padding(start = 12.dp, top = 10.dp, bottom = 10.dp)
                ) {
                    if ("" == "") {
                        Text("confirm password", color = Color(0xFF0E3E3E).copy(alpha = 0.45f))
                    }
                    innerTextField()
                }
            },
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 37.dp, top = 572.dp)
                .fillMaxWidth(0.85f)
                .height(41.dp)
        )

        // Sign Up Button
        TextButton(
            onClick = {},
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = 766.dp)
                .width(207.dp)
                .height(45.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50.dp))
                    .background(color = Color(0xFF24285B))
            ) {
                Text(
                    text = "Sign Up",
                    color = Color.White, // Black color for text
                    textAlign = TextAlign.Center,
                    style = TextStyle(fontSize = 20.sp),
                    modifier = Modifier
                        .align(Alignment.Center)
                )
            }
        }

        // Footer Links
        Text(
            text = buildAnnotatedString {
                append("By continuing, you agree to\n")
                withStyle(style = SpanStyle(color = Color.Black, fontSize = 14.sp)) { // Black color
                    append("Terms of Use")
                }
                append(" and ")
                withStyle(style = SpanStyle(color = Color.Black, fontSize = 14.sp)) { // Black color
                    append("Privacy Policy.")
                }
            },
            textAlign = TextAlign.Center,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 650.dp)
                .width(273.dp)
        )

        // Login Link
        Text(
            text = buildAnnotatedString {
                append("Already have an account?  ")
                withStyle(style = SpanStyle(color = Color.Black, fontSize = 13.sp)) { // Black color
                    append("Log In")
                }
            },
            textAlign = TextAlign.Center,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 822.dp)
                .width(273.dp)
        )
    }
}

@Preview
@Composable
fun CreateAccountPreview() {
    CreateAccount()
}
