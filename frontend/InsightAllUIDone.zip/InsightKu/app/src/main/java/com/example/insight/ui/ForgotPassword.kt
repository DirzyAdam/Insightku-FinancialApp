package com.example.insight.ui

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.compose.ui.tooling.preview.Preview
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.compose.ui.text.withStyle
import androidx.compose.foundation.Image
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.insight.R


class ForgotPassword : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_forgot_password)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}

@Composable
fun ALogin(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(color = Color(0xFFFFFFFF)) // Background utama
    ) {
        // Background Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(225.dp) // Menyesuaikan tinggi background
                .align(Alignment.TopCenter)
                .background(color = Color(0xFF24285B)) // Warna background baru
        )

        // Forgot Password Title
        Text(
            text = "Forgot Password",
            color = Color(0xFFDFF7E2),
            style = TextStyle(fontSize = 30.sp, textAlign = TextAlign.Center),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 80.dp) // Posisi lebih mendekati referensi
        )

        // Reset Password
        Text(
            text = "Reset Password?",
            color = Color(0xFF0E3E3E),
            style = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Medium),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 35.dp, top = 250.dp) // Menyesuaikan posisi lebih dekat dengan referensi
        )

        // Instruction Text
        Text(
            text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
            color = Color(0xFF0E3E3E),
            style = TextStyle(fontSize = 14.sp),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 35.dp, top = 285.dp)
                .width(350.dp)
        )

        // Email Label
        Text(
            text = "Enter Email Address",
            color = Color(0xFF093030),
            style = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Medium),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 35.dp, top = 380.dp)
        )

        // Email Input (BasicTextField)
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 35.dp, top = 410.dp)
                .width(350.dp)
                .height(50.dp) // Tentukan tinggi sesuai kebutuhan
        ) {
            // Gambar latar belakang
            Image(
                painter = painterResource(id = R.drawable.background_isi), // Nama gambar
                contentDescription = null, // Gambar hanya untuk dekorasi
                contentScale = ContentScale.FillBounds, // Sesuaikan gambar dengan ukuran Box
                modifier = Modifier
                    .fillMaxSize() // Isi seluruh ukuran Box
                    .clip(RoundedCornerShape(8.dp)) // Bentuk rounded sesuai kebutuhan
            )

            // BasicTextField di atas gambar
            BasicTextField(
                value = "example@gmail.com",
                onValueChange = {},
                singleLine = true,
                modifier = Modifier
                    .fillMaxSize() // Isi seluruh ukuran Box
                    .padding(horizontal = 16.dp, vertical = 12.dp), // Padding teks di dalam TextField
                textStyle = TextStyle(fontSize = 16.sp, color = Color(0xFF093030)),
                decorationBox = { innerTextField ->
                    innerTextField() // Teks Field
                }
            )
        }



        // Next Step Button
        TextButton(
            onClick = { /* TODO: Handle Next Step */ },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 500.dp)
                .size(width = 200.dp, height = 50.dp) // Memperbesar tombol sesuai referensi
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(30.dp)) // Rounded corners untuk Box
            ) {
                // Gambar latar belakang tombol
                Image(
                    painter = painterResource(id = R.drawable.bg_biru), // Nama gambar
                    contentDescription = null, // Gambar hanya untuk dekorasi
                    contentScale = ContentScale.FillBounds, // Gambar memenuhi ukuran Box
                    modifier = Modifier.fillMaxSize()
                )

                // Teks "Next Step" di atas gambar
                Text(
                    text = "Next Step",
                    color = Color(0xFFDFF7E2), // Warna teks sesuai desain
                    style = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold)
                )
            }
        }


        // Sign Up Button
        TextButton(
            onClick = { /* TODO: Handle Sign Up */ },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 580.dp)
                .size(width = 200.dp, height = 50.dp) // Memperbesar tombol sesuai referensi
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(30.dp)) // Rounded corners untuk Box
            ) {
                // Gambar latar belakang tombol
                Image(
                    painter = painterResource(id = R.drawable.background_isi), // Nama gambar
                    contentDescription = null, // Gambar hanya untuk dekorasi
                    contentScale = ContentScale.FillBounds, // Gambar memenuhi ukuran Box
                    modifier = Modifier.fillMaxSize()
                )

                // Teks "Sign Up" di atas gambar
                Text(
                    text = "Sign Up",
                    color = Color(0xFF0E3E3E), // Warna teks hitam
                    style = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold)
                )
            }
        }


        // Footer Text
        Text(
            text = buildAnnotatedString {
                append("Don’t have an account? ")
                withStyle(style = SpanStyle(color = Color(0xFF3299FF))) { append("Sign Up") }
            },
            color = Color(0xFF093030),
            style = TextStyle(fontSize = 13.sp),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 30.dp) // Posisi lebih mendekati referensi
        )
    }
}

@Preview(widthDp = 430, heightDp = 932)
@Composable
private fun ALoginPreview() {
    ALogin(Modifier)
}


