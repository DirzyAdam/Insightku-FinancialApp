package com.example.insight.ui

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.Image
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.insight.R
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button

import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.TextButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp

@Composable
fun Survey(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xff24285b))
    ) {
        // Title
        Text(
            text = "Survey",
            color = Color(0xffdff7e2),
            textAlign = TextAlign.Center,
            style = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 24.dp)
        )

        // Survey Form Fields
        SurveyFields(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 80.dp)
        )

        // Save Button
        SaveButton(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 16.dp)
        )
    }
}

@Composable
fun SurveyFields(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val fieldLabels = listOf(
            "Income Per Month",
            "Expense This Month",
            "Residence",
            "Main Purpose Saving",
            "Target Saving"
        )

        fieldLabels.forEachIndexed { index, label ->
            // Label untuk setiap field
            Text(
                text = label,
                color = Color(0xffdff7e2),
                fontSize = 16.sp,
                modifier = Modifier
                    .padding(start = 32.dp, bottom = 8.dp, end = 32.dp)
                    .align(Alignment.Start)
            )

            // Dropdown untuk Residence dan Main Purpose Saving
            if (index == 2 || index == 3) {
                BasicDropdownMenu(label)
            } else {
                // TextField untuk field lainnya
                BasicTextField(
                    value = "",
                    onValueChange = {},
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .padding(bottom = 16.dp)
                        .background(Color(0xffdff7e2), RoundedCornerShape(8.dp))
                        .padding(8.dp)
                )
            }
        }

        // Checkbox
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .padding(vertical = 16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .background(Color(0xffd9d9d9), shape = RoundedCornerShape(4.dp))
                    .clickable { /* Handle checkbox click */ }
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Is The Data You Entered Correct?",
                color = Color(0xffdff7e2),
                fontSize = 14.sp
            )
        }
    }
}

@Composable
fun BasicDropdownMenu(label: String) {
    var expanded: Boolean by remember { mutableStateOf(false) }
    var selectedOption: String by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxWidth(0.85f)
            .background(Color(0xffdff7e2), RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        // Dropdown field
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (selectedOption.isEmpty()) label else selectedOption,
                color = Color.Black,
                modifier = Modifier.weight(1f)
            )
            Icon(
                painter = painterResource(id = android.R.drawable.arrow_down_float),
                contentDescription = "Dropdown Icon",
                tint = Color.Gray
            )
        }

        // Dropdown menu
        if (expanded) {
            Column(
                modifier = Modifier
                    .background(Color(0xffdff7e2), RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                listOf("Option 1", "Option 2", "Option 3").forEach { option ->
                    Text(
                        text = option,
                        color = Color.Black,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable {
                                selectedOption = option
                                expanded = false
                            }
                    )
                }
            }
        }
    }
}


@Composable
fun SaveButton(modifier: Modifier = Modifier) {
    Button(
        onClick = {},
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xff437dfb)),
        shape = RoundedCornerShape(30.dp),
        modifier = modifier
            .width(210.dp)
            .height(47.dp)
    ) {
        Text(
            text = "Save",
            color = Color(0xffdff7e2),
            style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Bold)
        )
    }
}

@Preview
@Composable
fun SurveyPreview() {
    Survey()
}
