package com.example.insight.ui.fragment

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.insight.R

@Composable
fun GoalsFragment(navController: NavController, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF24285B))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 40.dp)
                .clip(RoundedCornerShape(bottomStart = 40.dp, bottomEnd = 40.dp))
                .background(Color(0xFF24285B))
                .weight(1f)
        ) {
            // Header
            Text(
                text = "Goals",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .padding(top = 16.dp)
                    .align(Alignment.TopCenter)
            )

            // Card: Target Section
            Box(
                modifier = Modifier
                    .padding(top = 80.dp)
                    .size(width = 376.dp, height = 212.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF343B94))
                    .align(Alignment.TopCenter)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Text(
                        text = "Target",
                        color = Color(0xFFDFF7E2),
                        fontSize = 16.sp,
                    )
                    Text(
                        text = "Rp. 12.000.000",
                        color = Color(0xFFDFF7E2),
                        fontSize = 40.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                    ) {
                        GoalItem(title = "New Phone", color = Color(0xFF437DFB), percentage = "47%")
                        GoalItem(title = "Tuition", color = Color(0xFF1FA80D), percentage = "31%")
                        GoalItem(title = "House", color = Color(0xFF6DB6FE), percentage = "28%")
                        GoalItem(title = "Clothes", color = Color(0xFFCD2323), percentage = "62%")
                    }
                }
            }

            // List of Goals
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 350.dp, start = 16.dp, end = 16.dp)
            ) {
                Text(
                    text = "List Goals",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium
                )
                GoalProgressBar(title = "New Phone", percentage = "47%", color = Color(0xFF437DFB))
                GoalProgressBar(title = "Tuition", percentage = "31%", color = Color(0xFF1FA80D))
                GoalProgressBar(title = "House", percentage = "28%", color = Color(0xFF6DB6FE))
                GoalProgressBar(title = "Clothes", percentage = "62%", color = Color(0xFFCD2323))
            }

            // Add Goals Button
            Button(
                onClick = { navController.navigate("addgoals") }, // Navigasi ke rute addgoals
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDFF7E2)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .padding(top = 450.dp)
                    .height(50.dp)
                    .fillMaxWidth(0.9f)
                    .align(Alignment.Center)
            ) {
                Text(
                    text = "Add Goals",
                    color = Color.Black,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Navigation Bar at the bottom
        BottomNavigationBar(navController = navController, selectedIndex = 3)
    }
}

@Composable
fun BottomNavigationBar(navController: NavController, selectedIndex: Int) {
    val icons = listOf(
        Pair(R.drawable.home, "home"), // Pastikan ini sesuai dengan grafik navigasi
        Pair(R.drawable.expense, "expense"), // Sesuaikan nama rute
        Pair(R.drawable.analisis, "analysis"),
        Pair(R.drawable.goals, "goals")
    )

    Row(
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .height(70.dp)
            .clip(shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp))
            .background(color = Color(0xffdff7e2))
            .padding(horizontal = 40.dp)
    ) {
        icons.forEachIndexed { index, icon ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .weight(1f)
                    .clickable {
                        if (index != selectedIndex) {
                            when (index) {
                                0 -> navController.navigate("home")
                                1 -> navController.navigate("expense") // Sesuaikan dengan nama rute
                                2 -> navController.navigate("analysis")
                                3 -> navController.navigate("goals")
                            }
                        }
                    }
            ) {
                Image(
                    painter = painterResource(id = icon.first),
                    contentDescription = icon.second,
                    colorFilter = if (index == selectedIndex) {
                        ColorFilter.tint(Color(0xff437dfb))
                    } else {
                        null
                    },
                    modifier = Modifier.size(25.dp)
                )
            }
        }
    }
}

@Composable
fun GoalItem(title: String, color: Color, percentage: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(horizontal = 8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(width = 60.dp, height = 8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(color)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = title,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = percentage,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun GoalProgressBar(title: String, percentage: String, color: Color) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Text(
            text = title,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f)
        )
        Box(
            modifier = Modifier
                .weight(3f)
                .height(14.dp)
                .clip(RoundedCornerShape(7.dp))
                .background(Color(0xFFDFF7E2))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(
                        percentage
                            .removeSuffix("%")
                            .toFloat() / 100f
                    )
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(7.dp))
                    .background(color)
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = percentage,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewGoalsFragment() {
    GoalsFragment(navController = rememberNavController())
}