package com.example.insight.ui

import AddTransactionScreen
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.insight.R
import com.example.insight.ui.fragment.AProfile
import com.example.insight.ui.fragment.ASettings
import com.example.insight.ui.fragment.AnalysisFragment
import com.example.insight.ui.fragment.BNotificationSettings
import com.example.insight.ui.fragment.CPasswordSettings
import com.example.insight.ui.fragment.EditProfileScreen
import com.example.insight.ui.fragment.ExpenseFragment
import com.example.insight.ui.fragment.GoalsFragment
import com.example.insight.ui.fragment.HomeFragment
import com.example.insight.ui.theme.InsightTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            InsightTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen()
                }
            }
        }
    }
}

@Composable
fun MainScreen() {
    val navController = rememberNavController()

    // Define the NavHost for navigation between fragments
    Column(modifier = Modifier.fillMaxSize()) {
        NavHost(navController = navController, startDestination = "home") {
            composable("home") { HomeFragment(onAddMoney = {}, navController = navController) }
            composable("profile") { AProfile(navController = navController) }
            composable("expense") { ExpenseFragment(navController = navController) }
            composable("add_transaction") { AddTransactionScreen(navController = navController) }
            composable("analysis") { AnalysisFragment(navController = navController) }
            composable("goals") { GoalsFragment(navController = navController) }
            composable("addgoals") { AddGoalScreen(navController = navController) }
            composable("editProfile") { EditProfileScreen() }
            composable("settings") { ASettings(navController = navController) }
            composable("password_settings") { CPasswordSettings() }
            composable("notifications_settings") { BNotificationSettings() }
        }

        // Add Bottom Navigation Bar
        BottomNavigationBar(navController = navController)
    }
}

@Composable
fun BottomNavigationBar(navController: NavController) {
    val icons = listOf(
        Pair(R.drawable.home, "home"),
        Pair(R.drawable.expense, "expense"),
        Pair(R.drawable.analisis, "analysis"),
        Pair(R.drawable.goals, "goals"),
        Pair(R.drawable.profile, "profile") // Added Profile to the bottom navigation
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(70.dp)
            .clip(shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp))
            .background(color = Color(0xffdff7e2))
            .padding(horizontal = 40.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxSize()
        ) {
            icons.forEach { icon ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            navController.navigate(icon.second)
                        }
                ) {
                    Image(
                        painter = painterResource(id = icon.first),
                        contentDescription = icon.second,
                        modifier = Modifier.size(25.dp)
                    )
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    InsightTheme {
        val navController = rememberNavController()
        MainScreen()
    }
}