package com.example.insight.ui.fragment

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.insight.R

@Composable
fun AProfile(navController: NavController, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(color = Color(0xFFF1FFF3)) // Warna latar belakang utama
    ) {
        // Header - Bagian atas layar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(color = Color(0xFF24285B)), // Warna header
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Profile",
                color = Color.White,
                style = TextStyle(
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            )

            // Ikon "Bring Back" sebagai tombol
            IconButton(
                onClick = { navController.popBackStack() }, // Navigasi kembali
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 16.dp, top = 16.dp)
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.bring_back), // Gambar ikon back
                    contentDescription = "Back Button",
                    tint = Color.White // Warna ikon putih
                )
            }
        }

        // Gambar Profil
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 150.dp)
                .size(120.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.profile), // Gambar lingkaran profil
                contentDescription = "Profile Picture",
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape) // Membuat lingkaran
                    .background(Color.Gray) // Placeholder warna
            )
        }

        // Nama dan ID pengguna
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 280.dp)
        ) {
            Text(
                text = "John Smith",
                color = Color(0xFF093030),
                style = TextStyle(
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            )
            Text(
                text = "ID: 25030024",
                color = Color(0xFF093030),
                style = TextStyle(
                    fontSize = 14.sp
                )
            )
        }

        // Tombol Edit Profile
        MenuButton(
            text = "Edit Profile",
            icon = { IconResource(R.drawable.edit_profile) }, // Ikon Edit Profile
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 30.dp, top = 350.dp),
            onClick = { navController.navigate("editProfile") } // Navigasi ke Edit Profile
        )

        // Tombol Setting
        MenuButton(
            text = "Setting",
            icon = { IconResource(R.drawable.setting_profile) }, // Ikon Setting
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 30.dp, top = 430.dp),
            onClick = { navController.navigate("settings") } // Navigasi ke Settings
        )

        // Tombol Logout
        MenuButton(
            text = "Logout",
            icon = { IconResource(R.drawable.log_out) }, // Ikon Logout
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 30.dp, top = 510.dp),
            onClick = { navController.popBackStack() } // Kembali ke halaman sebelumnya
        )
    }
}

// Fungsi untuk tombol menu (Edit Profile, Setting, Logout)
@Composable
fun MenuButton(
    text: String,
    icon: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .background(Color.Transparent)
            .clickable { onClick() } // Tambahkan onClick untuk navigasi
    ) {
        Box(
            modifier = Modifier
                .size(50.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF3299FF)), // Warna biru untuk ikon
            contentAlignment = Alignment.Center
        ) {
            icon()
        }
        Text(
            text = text,
            color = Color(0xFF093030),
            style = TextStyle(
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
        )
    }
}

// Ikon berbasis sumber daya XML
@Composable
fun IconResource(resId: Int, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(id = resId),
        contentDescription = null,
        modifier = Modifier.size(24.dp) // Ukuran ikon
    )
}

// Preview
@Preview(showBackground = true, widthDp = 430, heightDp = 932)
@Composable
fun AProfilePreview() {
    val navController = rememberNavController()
    AProfile(navController = navController)
}