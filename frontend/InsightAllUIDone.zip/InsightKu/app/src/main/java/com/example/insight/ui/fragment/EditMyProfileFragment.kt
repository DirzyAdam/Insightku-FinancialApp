package com.example.insight.ui.fragment

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.insight.R

@Composable
fun EditProfileScreen(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(color = Color(0xFFFFFFFF)) // Background color as per reference
    ) {
        // Header Background
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp) // Height similar to the reference provided
                .background(color = Color(0xFF24285B)), // Blue background color for header
        ) {
            // Bring Back IconButton
            IconButton(
                onClick = { /* TODO: Handle back action */ },
                modifier = Modifier
                    .padding(16.dp) // Padding from the top-left corner
                    .align(Alignment.TopStart) // Align to the top-start of the Box
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.bring_back), // Vector drawable resource
                    contentDescription = "Back",
                    tint = Color.Black, // Icon color
                    modifier = Modifier.size(24.dp) // Icon size
                )
            }
        }


        // Body Background
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .clip(RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp))
                .background(Color(0xFFFFFFFF)) // Green background color for body
                .padding(top = 200.dp) // Offset to align below the header
        )
    }

        // Title and Profile Image
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .padding(top = 40.dp)
                .fillMaxWidth()
        ) {
            Text(
                text = "Edit  Profile",
                style = TextStyle(
                    color = Color(0xFF000000),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            )
            Spacer(modifier = Modifier.height(20.dp))
            Box {
                // Profile Image
                Image(
                    painter = painterResource(id = R.drawable.profile),
                    contentDescription = "Profile Image",
                    modifier = Modifier
                        .size(117.dp)
                        .clip(CircleShape)
                        .background(Color.Gray) // Replace with actual image
                )
                // Camera Icon
                Icon(
                    painter = painterResource(id = R.drawable.camera_icon),
                    contentDescription = "Camera Icon",
                    tint = Color.Transparent,
                    modifier = Modifier
                        .size(25.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF00D09E))
                        .align(Alignment.BottomEnd)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "John Smith",
                style = TextStyle(
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF093030)
                )
            )
            Text(
                text = "ID: 25030024",
                style = TextStyle(
                    fontSize = 13.sp,
                    color = Color(0xFF093030)
                )
            )
        }

        // Account Settings
        Column(
            modifier = Modifier
                .padding(horizontal = 20.dp)
                .padding(top = 250.dp)
        ) {
            Text(
                text = "Account Settings",
                style = TextStyle(
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF093030)
                )
            )
            Spacer(modifier = Modifier.height(20.dp))

            // Username
            Text(
                text = "Username",
                style = labelStyle().copy(color = Color(0xFF000000)) // Menggunakan warna 0xFFDFF7E2
            )
            BasicTextField(
                value = "John Smith",
                onValueChange = {},
                modifier = inputFieldModifier()
                    .background(Color(0xFFDFF7E2)), // Menambahkan warna latar belakang
                textStyle = TextStyle(color = Color.Black) // Warna teks hitam agar terlihat
            )

// Phone
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "Phone",
                style = labelStyle().copy(color = Color(0xFF000000)) // Menggunakan warna 0xFFDFF7E2
            )
            BasicTextField(
                value = "+44 555 5555 55",
                onValueChange = {},
                modifier = inputFieldModifier()
                    .background(Color(0xFFDFF7E2)), // Menambahkan warna latar belakang
                textStyle = TextStyle(color = Color.Black) // Warna teks hitam agar terlihat
            )

// Email Address
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "Email Address",
                style = labelStyle().copy(color = Color(0xFF000000)) // Menggunakan warna 0xFFDFF7E2
            )
            BasicTextField(
                value = "example@example.com",
                onValueChange = {},
                modifier = inputFieldModifier()
                    .background(Color(0xFFDFF7E2)), // Menambahkan warna latar belakang
                textStyle = TextStyle(color = Color.Black) // Warna teks hitam agar terlihat
            )

            // Update Profile Button
            Spacer(modifier = Modifier.height(40.dp))
            Button(
                onClick = { /* TODO: Handle update profile */ },
                shape = RoundedCornerShape(30.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF24285B)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Text(
                    text = "Update Profile",
                    style = TextStyle(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFFDFF7E2)
                    )
                )
            }
        }
    }

@Composable
fun labelStyle() = TextStyle(
    fontSize = 15.sp,
    fontWeight = FontWeight.Medium,
    color = Color(0xFF093030)
)

@Composable
fun inputFieldModifier() = Modifier
    .fillMaxWidth()
    .height(50.dp)
    .clip(RoundedCornerShape(10.dp))
    .background(Color.White)
    .padding(horizontal = 16.dp, vertical = 14.dp)

@Preview(showBackground = true)
@Composable
fun EditProfileScreenPreview() {
    EditProfileScreen()
}
