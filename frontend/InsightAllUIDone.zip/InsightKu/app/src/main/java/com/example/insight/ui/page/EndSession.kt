package com.example.insight.ui.page

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun EndSession(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .requiredWidth(width = 339.dp)
            .requiredHeight(height = 300.dp)
            .background(color = Color(0xff24285b)) // Background warna utama
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(shape = RoundedCornerShape(20.dp))
                .background(color = Color.White) // Background kotak dialog
        )

        // Text Heading "End Session"
        Text(
            text = "End Session",
            color = Color(0xff0e3e3e),
            style = TextStyle(
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            ),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = 42.dp)
        )

        // Subtext "Are you sure you want to log out?"
        Text(
            text = "Are you sure you want to log out?",
            color = Color(0xff363130),
            style = TextStyle(fontSize = 17.sp),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = 83.dp)
        )

        // Button "Yes, End Session"
        TextButton(
            onClick = { /* TODO: Action for End Session */ },
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = 145.dp)
                .requiredWidth(218.dp)
                .requiredHeight(45.dp)
                .clip(RoundedCornerShape(30.dp))
                .background(color = Color(0xff24285b))
        ) {
            Text(
                text = "Yes, End Session",
                color = Color(0xffdff7e2),
                style = TextStyle(
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium
                ),
                textAlign = TextAlign.Center
            )
        }

        // Button "Cancel"
        TextButton(
            onClick = { /* TODO: Action for Cancel */ },
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = 201.dp)
                .requiredWidth(218.dp)
                .requiredHeight(45.dp)
                .clip(RoundedCornerShape(30.dp))
                .background(color = Color(0xffdff7e2))
        ) {
            Text(
                text = "Cancel",
                color = Color(0xff24285b),
                style = TextStyle(
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium
                ),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Preview(widthDp = 339, heightDp = 300)
@Composable
private fun EndSessionPreview() {
    EndSession(Modifier)
}
