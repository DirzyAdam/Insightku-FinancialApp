package com.example.insight.ui.fragment
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.BasicTextField

import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.graphics.Color.Companion
import androidx.compose.ui.text.TextStyle
import com.example.insight.R

class PwSettingFragment {
}

@Composable
fun CPasswordSettings(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(color = Color(0xff24285b))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(700.dp)
                .align(Alignment.BottomCenter)
                .background(color = Color(0xFFFFFFFF))
        )

        // Header
        Text(
            text = "Password Settings",
            color = Color.White,
            style = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 64.dp)
        )

        // Back Button Icon
        Image(
            painter = painterResource(id = R.drawable.bring_back),
            contentDescription = "Back Button",
            modifier = Modifier
                .padding(start = 16.dp, top = 64.dp)
                .size(24.dp)
                .align(Alignment.TopStart)
        )

        // Form Fields
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 32.dp)
                .align(Alignment.Center)
        ) {
            Text(text = "Current Password", color = Color(0xff093030), fontSize = 15.sp)
            Spacer(modifier = Modifier.height(8.dp))
            BasicTextField(
                value = "",
                onValueChange = {},
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .background(color = Color(0xffdff7e2), shape = RoundedCornerShape(12.dp))  // Changed color here
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))

            Text(text = "New Password", color = Color(0xff093030), fontSize = 15.sp)
            Spacer(modifier = Modifier.height(8.dp))
            BasicTextField(
                value = "",
                onValueChange = {},
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .background(color = Color(0xffdff7e2), shape = RoundedCornerShape(12.dp))  // Changed color here
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))

            Text(text = "Confirm New Password", color = Color(0xff093030), fontSize = 15.sp)
            Spacer(modifier = Modifier.height(8.dp))
            BasicTextField(
                value = "",
                onValueChange = {},
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .background(color = Color(0xffdff7e2), shape = RoundedCornerShape(12.dp))  // Changed color here
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            )
        }


        // Change Password Button
        Button(
            onClick = {},
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 32.dp)
                .height(50.dp)
                .width(200.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xff24285b))
        ) {
            Text(text = "Change Password", color = Color(0xffdff7e2), fontSize = 16.sp)
        }
    }
}

@Preview(widthDp = 430, heightDp = 932)
@Composable
private fun CPasswordSettingsPreview() {
    CPasswordSettings(Modifier)
}
