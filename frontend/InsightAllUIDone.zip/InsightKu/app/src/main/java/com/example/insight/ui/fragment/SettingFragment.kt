package com.example.insight.ui.fragment

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.insight.R
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.rememberNavController

@Composable
fun ASettings(
    modifier: Modifier = Modifier,
    navController: NavController // Menambahkan parameter navController
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(40.dp))
            .background(Color(0xff24285b))
    ) {
        // Background Image
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(806.dp)
                .background(Color(0xFFFFFFFF))
        )

        // Title
        Text(
            text = "Settings",
            color = Color(0xffdff7e2),
            style = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 64.dp)
        )

        // Back Icon
        Image(
            painter = painterResource(id = R.drawable.bring_back),
            contentDescription = "Bring Back",
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 38.dp, top = 69.dp)
                .size(19.dp)
                .clickable { navController.popBackStack() } // Navigasi kembali ke layar sebelumnya
        )

        // Password Settings Option
        TextButton(
            onClick = { navController.navigate("password_settings") }, // Navigasi ke Password Settings
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 37.dp, top = 213.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(23.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(31.dp)
                        .clip(CircleShape)
                        .background(Color(0xff24285b)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.key),
                        contentDescription = "Key Icon",
                        modifier = Modifier.size(16.dp)
                    )
                }
                Text(
                    text = "Password Settings",
                    color = Color(0xff363130),
                    style = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Medium)
                )
            }
        }

        // Notifications Settings Option
        TextButton(
            onClick = { navController.navigate("notifications_settings") }, // Navigasi ke Notifications Settings
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 37.dp, top = 283.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(23.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(31.dp)
                        .clip(CircleShape)
                        .background(Color(0xff24285b)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.notifications),
                        contentDescription = "Notifications Icon",
                        modifier = Modifier.size(16.dp)
                    )
                }
                Text(
                    text = "Notifications Settings",
                    color = Color(0xff363130),
                    style = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Medium)
                )
            }
        }
    }
}

@Preview(widthDp = 430, heightDp = 932)
@Composable
private fun ASettingsPreview() {
    val navController = rememberNavController() // Membuat NavController untuk preview
    ASettings(navController = navController)
}