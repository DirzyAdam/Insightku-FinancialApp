package com.example.insight.ui.theme

import androidx.compose.ui.graphics.Color

// Light theme colors
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Blue80 = Color(0xFF91DFFF)
val Green80 = Color(0xFFB9E5C4)
val Yellow80 = Color(0xFFFFE699)
val Orange80 = Color(0xFFFFC8A2)
val backgroundColor = Color (0xFF24285B)

// Dark theme colors
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
val textFieldColors = Color(0xFF4A89C6)
val Green40 = Color(0xFF4C9A76)
val Yellow40 = Color(0xFFC7A847)
val Orange40 = Color(0xFFD17C4C)

// Suggested primary color (Purple80 for light, Purple40 for dark)
val PrimaryLight = Purple80
val PrimaryDark = Purple40
