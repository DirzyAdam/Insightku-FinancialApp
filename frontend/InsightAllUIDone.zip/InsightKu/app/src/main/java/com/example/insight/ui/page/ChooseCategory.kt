package com.example.insight.ui.page

import androidx.compose.foundation.BorderStroke
import com.example.insight.R
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight

@Composable
fun ChooseCategory(modifier: Modifier = Modifier) {
    Surface(
        color = Color(0xff24285b),
        border = BorderStroke(1.dp, Color.Black),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .width(339.dp)
                .height(365.dp)
        ) {
            // Background Box
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White)
            )

            // Multiple Property1Activate boxes with different offsets
            Property1Activate(modifier = Modifier.align(Alignment.TopCenter).offset(y = 20.dp), categoryName = "Healthcare", backgroundColor = Color(0xff008C75))
            Property1Activate(modifier = Modifier.align(Alignment.TopCenter).offset(y = 74.dp), categoryName = "Food", backgroundColor = Color(0xffFC3D21))
            Property1Activate(modifier = Modifier.align(Alignment.TopCenter).offset(y = 128.dp), categoryName = "Shopping", backgroundColor = Color(0xff00B1F2), isSelected = true) // Selected Category
            Property1Activate(modifier = Modifier.align(Alignment.TopCenter).offset(y = 182.dp), categoryName = "Entertainment", backgroundColor = Color(0xffF1A04D))
            Property1Activate(modifier = Modifier.align(Alignment.TopCenter).offset(y = 236.dp), categoryName = "Living", backgroundColor = Color(0xff5A69A1))
            Property1Activate(modifier = Modifier.align(Alignment.TopCenter).offset(y = 290.dp), categoryName = "Transport", backgroundColor = Color(0xffF54A48))
            Property1Activate(modifier = Modifier.align(Alignment.TopCenter).offset(y = 344.dp), categoryName = "Utilities", backgroundColor = Color(0xff4C9A76))
            Property1Activate(modifier = Modifier.align(Alignment.TopCenter).offset(y = 398.dp), categoryName = "HouseHold", backgroundColor = Color(0xff1AD1C8))
            Property1Activate(modifier = Modifier.align(Alignment.TopCenter).offset(y = 452.dp), categoryName = "Education", backgroundColor = Color(0xffFF018786))
            Property1Activate(modifier = Modifier.align(Alignment.TopCenter).offset(y = 506.dp), categoryName = "Investment", backgroundColor = Color(0xff4EFF08))




            // Images placed on specific positions (if necessary)
        }
    }
}

@Composable
fun Property1Activate(
    modifier: Modifier = Modifier,
    categoryName: String,
    isSelected: Boolean = false,
    backgroundColor: Color
) {
    LazyColumn(
        modifier = modifier
            .width(323.dp)
            .height(45.dp)
            .padding(bottom = 8.dp) // Space between items
            .background(Color(0xFF24285B))
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(30.dp))
                    .background(if (isSelected) Color(0xff9B52FF) else backgroundColor) // Highlight selected category
            )
        }
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp), // Padding to align the text and icon
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Set icon and icon color based on category
                val (iconRes, iconColor) = when (categoryName) {
                    "Healthcare" -> Pair(R.drawable.love, Color(0xFF00FF00)) // Hijau
                    "Food" -> Pair(R.drawable.food, Color(0xFFFF0000)) // Hijau dan merah
                    "Shopping" -> Pair(R.drawable.shopping, Color(0xFF800080)) // Ungu
                    "Entertainment" -> Pair(R.drawable.entertainment, Color(0xFF0000FF)) // Biru
                    "Living" -> Pair(R.drawable.living, Color(0xFFFFFF00)) // Kuning
                    "Transport" -> Pair(R.drawable.transport, Color(0xFFFF0000)) // Merah
                    "Utilities" -> Pair(R.drawable.utilities, Color(0xFF4C9A76))
                    "HouseHold" -> Pair(R.drawable.house_hold, Color(0xFF91DFFF))
                    "Education" -> Pair(R.drawable.education, Color(0xFFFFE699))
                    "Investment" -> Pair(R.drawable.investment, Color(0xFFFFC8A2))

                    else -> Pair(R.drawable.love, Color(0xFF00FF00)) // Default ke hijau
                }
                Image(
                    painter = painterResource(id = iconRes),
                    contentDescription = "$categoryName Icon",
                    modifier = Modifier.size(24.dp),
                    colorFilter = ColorFilter.tint(iconColor) // Set icon color
                )
                Spacer(modifier = Modifier.width(8.dp)) // Space between icon and text
                Text(
                    text = categoryName, // Category name
                    color = Color(0xffdff7e2),
                    style = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Medium),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}


@Preview(widthDp = 339, heightDp = 365)
@Composable
private fun ChooseCategoryPreview() {
    ChooseCategory(modifier = Modifier)
}

