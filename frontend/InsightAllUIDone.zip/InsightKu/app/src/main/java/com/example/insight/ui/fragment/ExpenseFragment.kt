package com.example.insight.ui.fragment

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.insight.R
import com.example.insight.ui.page.CardItem
import getTransactions

@Composable
fun ExpenseFragment(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp))
                .background(Color(0xff24285b))
        ) {
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 175.dp, top = 66.dp, end = 50.dp)
            ) {
                Text(
                    text = "Expenses",
                    color = Color(0xffdff7e2),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }

            Column(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 140.dp)
            ) {
                Text(
                    text = "Total Expenses",
                    color = Color(0xffdff7e2),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Normal
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_salary),
                        contentDescription = "Total Icon",
                        modifier = Modifier.size(35.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Rp 500.000",
                        color = Color(0xffcd2323),
                        fontSize = 40.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            TextButton(
                onClick = { navController.navigate("add_transaction") }, // Tambahkan navigasi ke rute add_transaction
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 260.dp)
                    .clip(RoundedCornerShape(30.dp))
                    .background(Color(0xff437dfb))
                    .height(43.dp)
                    .width(335.dp)
            ) {
                Text(
                    text = "+ Add Transaction",
                    color = Color(0xffdff7e2),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 12.dp, top = 400.dp)
            ) {
                Text(
                    text = "Recent Transactions",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(16.dp))

                val transactions = getTransactions()
                transactions.forEach { transaction ->
                    CardItem(transaction)
                }
            }

            BottomNavigationBar(
                navController = navController // Gunakan NavController untuk navigasi
            )
        }
    }
}

@Composable
fun BottomNavigationBar(navController: NavController) {
    val icons = listOf(
        Pair(R.drawable.home, "home"),
        Pair(R.drawable.expense, "expense"),
        Pair(R.drawable.analisis, "analysis"),
        Pair(R.drawable.goals, "goals")
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 16.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .height(70.dp)
                .clip(shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp))
                .background(color = Color(0xffdff7e2))
                .padding(horizontal = 40.dp)
                .align(Alignment.BottomCenter)
        ) {
            icons.forEachIndexed { index, icon ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            navController.navigate(icon.second) // Pastikan route sesuai NavHost
                        }
                ) {
                    Image(
                        painter = painterResource(id = icon.first),
                        contentDescription = icon.second,
                        modifier = Modifier.size(25.dp),
                        colorFilter = if (index == 1) { // Expense item
                            ColorFilter.tint(Color(0xff437dfb))
                        } else {
                            null
                        }
                    )
                }
            }
        }
    }
}

@Preview(widthDp = 430, heightDp = 932)
@Composable
fun PreviewExpenseFragment() {
    ExpenseFragment(navController = rememberNavController())
}