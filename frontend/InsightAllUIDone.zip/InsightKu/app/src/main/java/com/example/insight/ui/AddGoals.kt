package com.example.insight.ui

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.launch

class AddGoalActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val navController = rememberNavController()
            AddGoalScreen(navController = navController)
        }
    }
}

@Composable
fun AddGoalScreen(navController: NavController) {
    var goalName by remember { mutableStateOf("") }
    var selectedDate by remember { mutableStateOf("Select Date") }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(color = Color(0xFFF1FFF3)) // Set background color to 0xF1FFF3
    ) {
        // Header Section with Back Button
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(color = Color(0xFF24285B)),
            contentAlignment = Alignment.TopStart
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(40.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Spacer(modifier = Modifier.width(15.dp))
                // Header Title
                Text(
                    text = "Add Goals",
                    style = TextStyle(fontSize = 24.sp),
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Content Section
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .padding(top = 200.dp)
        ) {
            // Goal Name Input
            Text(
                text = "Goal Name",
                fontSize = 16.sp,
                color = Color(0xFF002366),
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(color = Color(0xFF24285B), shape = RoundedCornerShape(8.dp))
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                BasicTextField(
                    value = goalName,
                    onValueChange = { goalName = it },
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Duration Section Header
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = "Duration", fontSize = 16.sp, color = Color(0xFF002366))

            // Date Picker Button
            Button(
                onClick = { /* Implement date picker dialog */ },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Text(text = selectedDate)
            }

            // Add Goal Button
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    if (goalName.isEmpty() || selectedDate == "Select Date") {
                        scope.launch {
                            Toast.makeText(context, "Please fill in all fields!", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        scope.launch {
                            Toast.makeText(context, "Goal Added Successfully!", Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Add Goal")
            }

            // Cancel Button
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = { navController.popBackStack() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDFF7E2)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .clip(RoundedCornerShape(30.dp))
            ) {
                Text(
                    text = "Cancel",
                    color = Color(0xFF24285B),
                    style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Bold)
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewAddGoalScreen() {
    val navController = rememberNavController()
    AddGoalScreen(navController = navController)
}