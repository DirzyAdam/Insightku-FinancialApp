package com.example.insight.ui

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import com.example.insight.R
import kotlinx.coroutines.launch

class AddGoalActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AddGoalScreen()
        }
    }
}

@Composable
fun AddGoalScreen() {
    var goalName by remember { mutableStateOf("") }
    var selectedDate by remember { mutableStateOf("Select Date") }
    val context = LocalContext.current
    val scope = rememberCoroutineScope() // for launching coroutines

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(color = Color(0xFFF1FFF3)) // Set background color to 0xF1FFF3
    ) {
        // Header Section with Back Button
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(color = Color(0xFF24285B)),
            contentAlignment = Alignment.TopStart
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Bring Back Button
                IconButton(onClick = { /* Handle back navigation */ }) {
                    Icon(
                        painter = painterResource(id = R.drawable.bring_back), // Replace with your bring_back image resource
                        contentDescription = "Bring Back",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(15.dp))
                // Header Title
                Text(
                    text = "Add Goals",
                    style = TextStyle(fontSize = 24.sp),
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Content Section (Goal Input, Date, Color Picker, etc.)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .padding(top = 200.dp) // Offset the content to go below the header
        ) {
            // Goal Name Input using BasicTextField
            Text(
                text = "Goal Name",
                fontSize = 16.sp,
                color = Color(0xFF002366),
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(color = Color(0xFF24285B), shape = RoundedCornerShape(8.dp))
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                BasicTextField(
                    value = goalName,
                    onValueChange = { goalName = it },
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    modifier = Modifier.fillMaxWidth()
                )
                {
                    Text(text = goalName)
                }
            }

            // Duration Section Header
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = "Duration", fontSize = 16.sp, color = Color(0xFF002366))

            // Date Picker Button
            Button(
                onClick = { /* Implement date picker dialog */ },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Text(text = selectedDate)
            }

            // Goal Amount Section
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = "Goal Amount", fontSize = 16.sp, color = Color(0xFF002366))

            // Color Picker (Example: Simple color views)
            Row(
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                ColorOption(Color.Black)
                ColorOption(Color.Green)
                ColorOption(Color.Yellow)
                ColorOption(Color.Red)
                ColorOption(Color.Blue)
            }

            // Add Goal Button
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    if (goalName.isEmpty() || selectedDate == "Select Date") {
                        // Use LaunchedEffect to show Toast in a coroutine
                        scope.launch {
                            Toast.makeText(context, "Please fill in all fields!", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        scope.launch {
                            Toast.makeText(context, "Goal Added Successfully!", Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Add Goal")
            }

            // Cancel Button
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedButton(
                onClick = {
                    goalName = ""
                    selectedDate = "Select Date"
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Cancel")
            }
        }
    }
}

@Composable
fun ColorOption(color: Color) {
    Box(
        modifier = Modifier
            .size(40.dp, 20.dp) // Mengubah ukuran menjadi persegi panjang
            .background(color, shape = RoundedCornerShape(4.dp)) // Sudut melengkung kecil, gunakan 0.dp untuk persegi sempurna
            .padding(4.dp)
    )
}


// Preview
@Preview(showBackground = true)
@Composable
fun PreviewAddGoalScreen() {
    AddGoalScreen()
}
