package com.example.insight.ui.fragment

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import com.example.insight.R
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.em

@Composable
fun XGoals(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(40.dp))
            .background(Color(0xFF24285B))
    ) {
        // Header
        Text(
            text = "Goals",
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 16.dp)
        )

        // Card: Target Section
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 80.dp)
                .size(width = 376.dp, height = 212.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF343B94))
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxSize()
            ) {
                Text(
                    text = "Target",
                    color = Color(0xFFDFF7E2),
                    fontSize = 16.sp,
                )
                Text(
                    text = "Rp. 12.000.000",
                    color = Color(0xFFDFF7E2),
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Medium
                )
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                ) {
                    GoalItem(title = "New Phone", color = Color(0xFF437DFB), percentage = "47%")
                    GoalItem(title = "Tuition", color = Color(0xFF1FA80D), percentage = "31%")
                    GoalItem(title = "House", color = Color(0xFF6DB6FE), percentage = "28%")
                    GoalItem(title = "Clothes", color = Color(0xFFCD2323), percentage = "62%")
                }
            }
        }

        // List of Goals
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 350.dp, start = 16.dp, end = 16.dp)
        ) {
            Text(
                text = "Top Goals",
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium
            )
            GoalProgressBar(title = "New Phone", percentage = "47%", color = Color(0xFF437DFB))
            GoalProgressBar(title = "Tuition", percentage = "31%", color = Color(0xFF1FA80D))
            GoalProgressBar(title = "House", percentage = "28%", color = Color(0xFF6DB6FE))
            GoalProgressBar(title = "Clothes", percentage = "62%", color = Color(0xFFCD2323))
        }

        // Add Expense Button
        Button(
            onClick = { /* Handle Add Expense action here */ },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDFF7E2)), // Gunakan containerColor
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .align(Alignment.Center)
                .padding(top = 250.dp)
                .height(50.dp)
                .fillMaxWidth(0.9f)
        ) {
            Text(
                text = "Add Expense",
                color = Color.Black, // Sesuaikan warna teks agar kontras
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }


        // Navigation Bar
        BottomNavigationBar(
            selectedIndex = 3,
            onItemSelected = { index ->
                // Handle navigation item clicks here
            },
            modifier = Modifier
                .align(Alignment.BottomCenter)
        )
    }
}


// Helper Composable for individual goals
@Composable
fun GoalItem(title: String, color: Color, percentage: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(horizontal = 8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(width = 60.dp, height = 8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(color)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = title,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = percentage,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

// Helper Composable for progress bars
@Composable
fun GoalProgressBar(title: String, percentage: String, color: Color) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Text(
            text = title,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f)
        )
        Box(
            modifier = Modifier
                .weight(3f)
                .height(14.dp)
                .clip(RoundedCornerShape(7.dp))
                .background(Color(0xFFDFF7E2))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(percentage.removeSuffix("%").toFloat() / 100f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(7.dp))
                    .background(color)
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = percentage,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

// Helper Composable for navigation item
@Composable
fun NavigationItem(icon: Int, description: String) {
    Icon(
        painter = painterResource(id = icon),
        contentDescription = description,
        modifier = Modifier.size(24.dp)
    )
}


@Composable
fun Property1Inactive(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .requiredWidth(200.dp)
            .requiredHeight(14.dp)
    ) {
    }
}

@Preview(widthDp = 430, heightDp = 932)
@Composable
private fun XGoalsPreview() {
    XGoals(Modifier)
}
