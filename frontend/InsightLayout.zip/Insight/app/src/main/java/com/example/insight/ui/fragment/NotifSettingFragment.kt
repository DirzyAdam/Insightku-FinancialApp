package com.example.insight.ui.fragment

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.example.insight.R
import androidx.compose.ui.tooling.preview.Preview

class NotifSettingFragment

@Composable
fun BNotificationSettings(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(40.dp))
            .background(Color(0xFF24285B))
    ) {
        // Background
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(806.dp)
                .background(Color(0xFFDFF7E2))
        )

        // Title
        Text(
            text = "Notification Settings",
            style = TextStyle(
                color = Color(0xFFDFF7E2),
                fontSize = 20.sp,
                lineHeight = 1.1.em
            ),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 64.dp)
        )

        // Back Button
        Image(
            painter = painterResource(id = R.drawable.bring_back),
            contentDescription = "Back Button",
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 38.dp, top = 69.dp)
                .size(19.dp)
        )

        // Notification Options
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 57.dp, top = 207.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp) // Mengatur jarak antar item
        ) {
            NotificationItem("General Notification")
            NotificationItem("Sound")
            NotificationItem("Sound Call")
            NotificationItem("Vibrate")
        }
    }
}

@Composable
private fun NotificationItem(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .background(Color.White, RoundedCornerShape(10.dp))
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Text for the notification option
            Text(
                text = text,
                style = TextStyle(
                    color = Color(0xFF363130),
                    fontSize = 15.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
                )
            )
            // Switch
            val isChecked = remember { mutableStateOf(true) }
            Switch(
                checked = isChecked.value,
                onCheckedChange = { isChecked.value = it }
            )
        }
    }
}

@Preview(widthDp = 430, heightDp = 932)
@Composable
private fun BNotificationSettingsPreview() {
    BNotificationSettings()
}