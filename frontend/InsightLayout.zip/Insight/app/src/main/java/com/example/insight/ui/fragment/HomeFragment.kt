package com.example.insight.ui.fragment

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.tooling.preview.Preview
import com.example.insight.R
import com.example.insight.ui.page.CardItem
import getTransactions


@Composable
fun AHomeBottomNavigation(modifier: Modifier = Modifier) {
    val selectedTabIndex = remember { mutableStateOf(0) } // Menyimpan state tab yang dipilih

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(color = Color(0xff24285b))
            .padding(16.dp)
    ) {
        // Rectangle background
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .requiredHeight(744.dp)
                .background(color = Color.White)
        )

        // Welcome Section
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 16.dp, top = 40.dp)
        ) {
            Text(
                text = "Welcome! John",
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Jonh",
                color = Color.White,
                fontSize = 20.sp
            )
        }

        // Top Card (Your Balance)
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 100.dp)
                .fillMaxWidth(0.85f)
                .requiredHeight(201.dp)
                .clip(RoundedCornerShape(13.5.dp))
                .background(Color(0xff343b94))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(30.dp),
                horizontalAlignment = Alignment.Start // Mengatur rata kiri untuk elemen dalam Column
            ) {
                Text(
                    text = "Total Balances",
                    color = Color.White,
                    fontSize = 16.sp,
                    modifier = Modifier.fillMaxWidth() // Mengisi lebar penuh agar teks rata kiri
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Rp 5.000.000",
                    color = Color(0xff35d486),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Add Money button
        TextButton(
            onClick = { /* TODO: Add action */ },
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 220.dp)
                .fillMaxWidth(0.78f)
                .requiredHeight(43.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(30.dp))
                    .background(Color(0xff437dfb))
            ) {
                Text(
                    text = " + Add Money",
                    color = Color(0xffdff7e2),
                    textAlign = TextAlign.Center,
                    style = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold),
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }

        // Saving Progress
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 330.dp)
                .fillMaxWidth(0.85f)
                .requiredHeight(92.dp)
                .clip(RoundedCornerShape(13.5.dp))
                .background(Color(0xff24285b))
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "Saving Progress",
                    color = Color.White,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.Gray)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.3f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xff35d486))
                    )
                }
            }
        }

        // Recent Transactions
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 450.dp)
                .fillMaxWidth()
        ) {
            Text(
                text = "Recent Transaction",
                color = Color.Black,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 16.dp, bottom = 8.dp)
            )

            // Menambahkan CardItem untuk menampilkan daftar transaksi
            val transactions = getTransactions() // Ambil daftar transaksi
            Column(modifier = Modifier.fillMaxWidth()) {
                transactions.forEach { transaction ->
                    CardItem(transaction) // Menampilkan transaksi menggunakan CardItem
                }
            }
        }


        // Bottom Navigation
        BottomNavigationBar(
            selectedIndex = selectedTabIndex.value,
            onItemSelected = { selectedTabIndex.value = it },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 16.dp)
        )
    }
}



@Composable
fun BottomNavigationBar(
    selectedIndex: Int,
    onItemSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val icons = listOf(
        Pair(R.drawable.home, "Home"),
        Pair(R.drawable.transactions, "Expense"),
        Pair(R.drawable.analisis, "Analysis"),
        Pair(R.drawable.goals, "Goals")
    )

    Row(
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .height(70.dp)
            .clip(shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp))
            .background(color = Color(0xffdff7e2)) // Light green background
            .padding(horizontal = 40.dp)
    ) {
        icons.forEachIndexed { index, icon ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .weight(1f)
                    .clickable { onItemSelected(index) }
            ) {
                Image(
                    painter = painterResource(id = icon.first),
                    contentDescription = icon.second,
                    colorFilter = if (index == selectedIndex) {
                        ColorFilter.tint(Color(0xff437dfb)) // Highlighted (Blue)
                    } else {
                        null // Default icon
                    },
                    modifier = Modifier.size(25.dp)
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewAHomeBottomNavigation() {
    AHomeBottomNavigation() // Preview tampilan dari AHomeBottomNavigation
}

@Preview(showBackground = true)
@Composable
fun PreviewBottomNavigationBar() {
    BottomNavigationBar(selectedIndex = 0, onItemSelected = {})
}
