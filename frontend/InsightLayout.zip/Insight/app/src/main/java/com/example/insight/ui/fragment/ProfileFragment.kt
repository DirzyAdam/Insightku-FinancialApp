package com.example.insight.ui.fragment

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.foundation.Image
import androidx.compose.ui.draw.clip
import com.example.insight.R

@Composable
fun AProfile(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(color = Color(0xff24285b))
    ) {
        // Header Section
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(250.dp)
                .background(color = Color(0xff24285b))
        ) {
            // Back Button
            IconButton(
                onClick = { /* TODO: Handle back navigation */ },
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 16.dp, top = 16.dp)
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.bring_back),
                    contentDescription = "Back",
                    tint = Color.White
                )
            }

            // Profile Picture
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(Color.Gray) // Placeholder for profile image
            ) {
                Image(
                    painter = painterResource(id = R.drawable.profile), // Replace with your image
                    contentDescription = "Profile Picture",
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Notification Button
            IconButton(
                onClick = { /* TODO: Handle notifications */ },
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(end = 16.dp, top = 16.dp)
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.notifications),
                    contentDescription = "Notifications",
                    tint = Color.White
                )
            }
        }

        // Content Section
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 200.dp)
                .background(Color(0xffdff7e2), RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp)),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(40.dp))

            // Name and ID
            Text(
                text = "John Smith",
                style = TextStyle(
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xff24285b)
                )
            )
            Text(
                text = "ID: 25030024",
                style = TextStyle(
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Light,
                    color = Color(0xff24285b)
                )
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Action Buttons
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.Start // Set tombol rata kiri
            ) {
                ProfileOptionButton(
                    imageResource = R.drawable.edit_profile,
                    text = "Edit Profile",
                    onClick = { /* TODO: Navigate to Edit Profile */ }
                )
                ProfileOptionButton(
                    imageResource = R.drawable.setting_profile,
                    text = "Settings",
                    onClick = { /* TODO: Navigate to Settings */ }
                )
                ProfileOptionButton(
                    imageResource = R.drawable.log_out,
                    text = "Logout",
                    onClick = { /* TODO: Handle Logout */ }
                )
            }
        }
    }
}

@Composable
fun ProfileOptionButton(
    imageResource: Int,
    text: String,
    onClick: () -> Unit
) {
    TextButton(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp)
            .height(56.dp),
        colors = ButtonDefaults.textButtonColors(contentColor = Color(0xff093030))
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Start // Set konten rata kiri
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xff6db6fe))
                    .padding(4.dp)
            ) {
                Image(
                    painter = painterResource(id = imageResource),
                    contentDescription = text,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = text,
                style = TextStyle(
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xff093030)
                )
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun AProfilePreview() {
    AProfile()
}
