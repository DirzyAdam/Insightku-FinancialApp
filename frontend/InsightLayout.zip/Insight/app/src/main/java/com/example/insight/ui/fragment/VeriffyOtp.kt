package com.example.insight.ui.fragment

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.res.painterResource
import com.example.insight.R

class VerifyOtp

@Composable
fun BNewPassword(modifier: Modifier = Modifier) {
    // Main background
    Box(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(40.dp))
            .background(Color(0xFF24285B)) // Background utama dengan warna terang
    ) {
        // Secondary background
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = 250.dp)
                .width(598.dp)
                .height(745.dp)
                .clip(RoundedCornerShape(40.dp))
                .background(Color(0xFFFFFFFF )) // Background kedua dengan warna gelap
        )

        // Title
        Text(
            text = "Verify OTP",
            color = Color(0xffdff7e2),
            textAlign = TextAlign.Center,
            style = TextStyle(fontSize = 30.sp),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = 100.dp)
        )

        // Email information
        Text(
            text = buildAnnotatedString {
                withStyle(SpanStyle(color = Color(0xff093030), fontSize = 15.sp, fontWeight = FontWeight.Medium)) {
                    append("We Have Sent OTP Code To Your Email\n")
                }
                withStyle(SpanStyle(color = Color(0xff093030), fontSize = 15.sp, fontWeight = FontWeight.Bold)) {
                    append("Example@gmail.com")
                }
            },
            modifier = Modifier
                .align(Alignment.TopStart)
                .offset(x = 20.dp, y = 273.dp)
                .width(411.dp)
        )

        // OTP input fields
        Row(
            horizontalArrangement = Arrangement.spacedBy(15.dp),
            modifier = Modifier
                .align(Alignment.TopStart)
                .offset(x = 55.dp, y = 357.dp)
        ) {
            repeat(4) { ConfirmNewpasswordTextField() }
        }

        // Resend OTP text
        Text(
            text = "Resend OTP",
            color = Color(0xff437dfb),
            textAlign = TextAlign.Center,
            style = TextStyle(fontSize = 12.sp),
            modifier = Modifier
                .align(Alignment.TopStart)
                .offset(x = 342.dp, y = 444.dp)
        )


        // Back button icon using vector drawable
        Image(
            painter = painterResource(id = R.drawable.bring_back),
            contentDescription = "Back Button",
            modifier = Modifier
                .align(Alignment.TopStart)
                .offset(x = 37.dp, y = 62.dp)
                .size(19.dp, 16.dp)
        )


        // Next button
        TextButton(
            onClick = { /* Action */ },
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = 719.dp)
                .width(234.dp)
                .height(45.dp)
        ) {
            Property1Activate()
        }
    }
}

@Composable
fun ConfirmNewpasswordTextField(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(66.dp, 56.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xffdff7e2))
    )
}

@Composable
fun Property1Activate(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(30.dp))
            .background(Color(0xff24285b))
    ) {
        Text(
            text = "Next",
            color = Color(0xffdff7e2),
            textAlign = TextAlign.Center,
            style = TextStyle(fontSize = 20.sp),
            modifier = Modifier
                .align(Alignment.Center)
        )
    }
}

@Preview(widthDp = 430, heightDp = 932)
@Composable
private fun BNewPasswordPreview() {
    BNewPassword()
}
