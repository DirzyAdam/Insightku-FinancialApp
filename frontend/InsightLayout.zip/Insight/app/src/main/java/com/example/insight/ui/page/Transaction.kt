import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Data model
data class Transaction(
    val title: String,  // Nama transaksi (misalnya: belanja, transportasi)
    val amount: String, // Jumlah uang yang terlibat dalam transaksi
    val date: String    // Tanggal transaksi
)

// Simulasi fungsi untuk mendapatkan daftar transaksi
fun getTransactions(): List<Transaction> {
    return listOf(
        Transaction("Groceries", "Rp 100,000", "2024-11-20"),
        Transaction("Transport", "Rp 50,000", "2024-11-21"),
        Transaction("Entertainment", "Rp 200,000", "2024-11-22"),
        Transaction("Salary", "Rp 5,000,000", "2024-11-23")
    )
}

// Property1Inactive composable yang belum didefinisikan sebelumnya
@Composable
fun AddTransactions(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(80.dp)  // Ukuran kotak yang lebih kecil
            .background(Color.Gray)  // Warna latar belakang kotak
    ) {
        // Isi tambahan jika diperlukan
    }
}

// Composable utama untuk tampilan
@Composable
fun AddTransactionScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFEFF5F5)) // Warna latar belakang
    ) {
        // Header dan Teks Judul
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF24285B))
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Add Transaction",
                color = Color.White,
                style = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Bold)
            )
        }

        // Konten Utama
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 100.dp)
                .padding(horizontal = 16.dp)
        ) {
            // Input Tanggal
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                DateSelector(label = "Day")
                DateSelector(label = "Month")
                DateSelector(label = "Year")
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Input Jumlah
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Enter Amount",
                    style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium),
                    color = Color(0xFF24285B)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF343B94)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "300.000",
                        color = Color.White,
                        style = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Pilih Kategori
            Column {
                Text(
                    text = "Category",
                    style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium),
                    color = Color(0xFF24285B)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFDFF7E2)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Healthcare",
                        color = Color(0xFF24285B),
                        style = TextStyle(fontSize = 16.sp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            // Tombol "Add Expense" dan "Cancel"
            Button(
                onClick = { /* Add Expense */ },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF437DFB)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .clip(RoundedCornerShape(30.dp))
            ) {
                Text(
                    text = "Add Expense",
                    color = Color.White,
                    style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Bold)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { /* Cancel */ },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDFF7E2)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .clip(RoundedCornerShape(30.dp))
            ) {
                Text(
                    text = "Cancel",
                    color = Color(0xFF24285B),
                    style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Bold)
                )
            }
        }
    }
}

@Composable
fun DateSelector(label: String) {
    Box(
        modifier = Modifier
            .width(100.dp)
            .height(50.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF343B94)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = Color.White,
            style = TextStyle(fontSize = 16.sp)
        )
    }
}

@Preview
@Composable
fun PreviewAddTransactionScreen() {
    AddTransactionScreen()
}
