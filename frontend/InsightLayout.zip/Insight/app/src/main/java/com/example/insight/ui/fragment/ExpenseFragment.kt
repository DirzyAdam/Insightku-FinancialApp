import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.insight.R
import com.example.insight.ui.page.CardItem


@Composable
fun AExpenses(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.White) // Background utama
    ) {
        // Konten utama
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp))
                .background(Color(0xff24285b))
        ) {
            // Header
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 175.dp, top = 66.dp, end = 50.dp)
            ) {
                Text(
                    text = "Expenses",
                    color = Color(0xffdff7e2),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }

            // Back button
            Image(
                painter = painterResource(id = R.drawable.bring_back),
                contentDescription = "Back",
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 25.dp, top = 66.dp)
                    .size(19.dp)
            )

            // Total Expenses Section
            Column(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 140.dp)
            ) {
                Text(
                    text = "Total Expenses",
                    color = Color(0xffdff7e2),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Normal
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_salary),
                        contentDescription = "Total Icon",
                        modifier = Modifier.size(35.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Rp 500.000",
                        color = Color(0xffcd2323),
                        fontSize = 40.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Add Transaction Button
            TextButton(
                onClick = { /* Add your action here */ },
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 260.dp)
                    .clip(RoundedCornerShape(30.dp))
                    .background(Color(0xff437dfb))
                    .height(43.dp)
                    .width(335.dp)
            ) {
                Text(
                    text = "+ Add Transaction",
                    color = Color(0xffdff7e2),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Recent Transactions Section
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 39.dp, top = 400.dp)
            ) {
                Text(
                    text = "Recent Transactions",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(16.dp))

                val transactions = getTransactions()
                transactions.forEach { transaction ->
                    CardItem(transaction)
                }
            }

            // Bottom Navigation
            Row(
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp)) // Sudut melengkung
                    .background(Color(0xffdff7e2)) // Background hijau muda
                    .padding(horizontal = 30.dp, vertical = 16.dp) // Padding untuk kesesuaian desain
            ) {
                // Home Icon
                Image(
                    painter = painterResource(id = R.drawable.home),
                    contentDescription = "Home",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(31.dp)
                )
                // Transaction Icon
                Image(
                    painter = painterResource(id = R.drawable.transactions),
                    contentDescription = "Transactions",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(31.dp)
                )
                // Analytics Icon
                Image(
                    painter = painterResource(id = R.drawable.analisis),
                    contentDescription = "Analytics",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(31.dp)
                )
                // Goals Icon
                Image(
                    painter = painterResource(id = R.drawable.goals),
                    contentDescription = "Goals",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(31.dp)
                )
            }
        }
    }
}

@Preview(widthDp = 430, heightDp = 932)
@Composable
fun AExpensesPreview() {
    AExpenses()
}

