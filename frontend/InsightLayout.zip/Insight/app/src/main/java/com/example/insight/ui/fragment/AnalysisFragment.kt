package com.example.insight.ui.fragment

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.material3.Text
import androidx.compose.ui.text.font.FontWeight
import com.example.insight.R

@Composable
fun Analisis(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(color = Color(0xff24285b)) // Warna background utama
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Analysis",
                color = Color(0xffdff7e2),
                textAlign = TextAlign.Center,
                style = TextStyle(fontSize = 20.sp)
            )
        }

        // Konten Utama
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 100.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Total Income Card
            TotalIncomeCard(income = "Rp 5.000.000")

            // Chart Placeholder
            ChartCard()

            // Total Expenses Card
            InfoCard(title = "Total Expenses", amount = "Rp. 300.000", amountColor = Color(0xffe91e63))

            // Total Saving Card
            InfoCard(title = "Total Saving", amount = "Rp. 300.000", amountColor = Color(0xff4caf50))
        }

        // Bottom Navigation
        BottomNavigationLightMode(
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
fun TotalIncomeCard(income: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(175.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(color = Color(0xff6db6fe )),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 50.dp)
        ) {
            Text(
                text = "Total Expenses",
                color = Color(0xffdff7e2),
                fontSize = 16.sp,
                fontWeight = FontWeight.Normal
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_salary),
                    contentDescription = "Total Icon",
                    modifier = Modifier.size(35.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Rp 500.000",
                    color = Color(0xff4caf50 ),
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun ChartCard(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(300.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(color = Color(0xffdff7e2)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "Grafik disini",
            color = Color.Gray,
            style = TextStyle(fontSize = 16.sp)
        )
    }
}

@Composable
fun InfoCard(title: String, amount: String, amountColor: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(70.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(color = Color(0xff6db6fe)),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = Color.White,
                style = TextStyle(fontSize = 16.sp)
            )
            Text(
                text = amount,
                color = amountColor,
                style = TextStyle(fontSize = 16.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            )
        }
    }
}

@Composable
fun BottomNavigationLightMode(modifier: Modifier = Modifier) {
    Row(
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .height(100.dp) // Tinggi navigation bar disesuaikan
            .clip(shape = RoundedCornerShape(topStart = 50.dp, topEnd = 50.dp)) // Sudut membulat lebih besar
            .background(color = Color(0xffdff7e2)) // Warna hijau muda
            .padding(horizontal = 30.dp, vertical = 20.dp) // Padding dalam bar
    ) {
        // Ikon Home
        Image(
            painter = painterResource(id = R.drawable.home),
            contentDescription = "Home",
            colorFilter = ColorFilter.tint(Color(0xff437dfb)), // Ikon aktif diberi warna biru
            modifier = Modifier.size(35.dp)
        )
        // Ikon Transactions
        Image(
            painter = painterResource(id = R.drawable.transactions),
            contentDescription = "Transactions",
            colorFilter = ColorFilter.tint(Color.Gray), // Ikon non-aktif diberi warna abu-abu
            modifier = Modifier.size(35.dp)
        )
        // Ikon Analytics
        Image(
            painter = painterResource(id = R.drawable.analisis),
            contentDescription = "Analytics",
            colorFilter = ColorFilter.tint(Color.Gray),
            modifier = Modifier.size(35.dp)
        )
        // Ikon Profile
        Image(
            painter = painterResource(id = R.drawable.profile),
            contentDescription = "Profile",
            colorFilter = ColorFilter.tint(Color.Gray),
            modifier = Modifier.size(35.dp)
        )
    }
}


@Preview(showBackground = true, widthDp = 430, heightDp = 932)
@Composable
fun AnalisisPreview() {
    Analisis()
}
